/* ==========================================================================
 *  SIP Asset Library — Aurora Edition (rewritten 15-05-2026)
 *  ------------------------------------------------------------------------
 *  Renders every old-Rappid asset type (examples.Track, examples.PointMachine,
 *  examples.Signal*, examples.Shaunt, examples.BusBar, …) using the new
 *  Aurora SVG visuals from sip/*.svg.
 *
 *  >>>  IMPORTANT  <<<
 *  This library works DIRECTLY on the legacy Rappid cell shape:
 *
 *      { type, position:{x,y}, size:{width,height}, angle, z, id, attrs:{…} }
 *
 *  So the editor's getLayout() returns exactly { cells: [...] } and that JSON
 *  drops straight into the advancesipview.SipView1 column — same shape every
 *  existing site already uses, same shape Sview.cshtml already consumes.
 *
 *  Public API
 *  ----------
 *    SIP.GROUPS                  – toolbox group definitions
 *    SIP.PALETTE                 – every paintable asset, in toolbox order
 *    SIP.spec(type)              – lookup descriptor for a Rappid type
 *    SIP.makeCell(type, x, y)    – build a fresh default cell (post-drag)
 *    SIP.renderCell(cell)        – cell  → SVG fragment (for editor canvas)
 *    SIP.renderIcon(type)        – type  → mini SVG (toolbox preview)
 *    SIP.renderYard({viewBox, cells, background?, className?})
 *                                 – build the full <svg>…</svg> for export
 *
 *  Cell `attrs` defaults are populated by makeCell() with EXACTLY the selectors
 *  the Sview.cshtml runtime mutates (path / body / circle1 / path1 / label),
 *  so the first MQTT tick never trips on a missing nested object.
 * ========================================================================== */

(function () {
    'use strict';

    /* ------------------------------------------------------------------------ *
     *  Theme — every colour lives here so a re-skin is a single edit. Mirrors
     *  the CSS variables in sip-editor.css.
     * ------------------------------------------------------------------------ */
    const T = {
        railBase: '#7E7E7E',
        railEdge: '#ffffff',
        sleeper: '#515151',

        sectionClear: '#22D142',
        sectionOcc: '#FF2E2E',
        sectionRoute: '#22d3ee',
        sectionEdge: 'rgba(255,255,255,0.18)',
        sectionText: '#ffffff',

        signalBody: '#606060',
        lampOuter: '#4C4C4C',
        lampOff: '#ffffff',
        lampRed: '#FF2E2E',
        lampYellow: '#FFD400',
        lampGreen: '#22D142',

        pmBody: '#5B6168',
        pmDot: '#ffffff',
        pmDotDim: 'rgba(255,255,255,0.25)',

        shuntBody: '#5B6168',

        busBar: '#9aa8c4',
        bbLabel: '#ffffff',

        routeLine: '#606060',

        siding: '#e8edf6',

        labelDefault: '#d7d7d7',
        labelHi: '#FFC919',
        labelFont: "'Plus Jakarta Sans', 'IBM Plex Sans', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif"
    };

    /* ------------------------------------------------------------------------ *
     *  Small helpers
     * ------------------------------------------------------------------------ */
    function escapeXml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
    function uid() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            const r = Math.random() * 16 | 0;
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
    }
    function attrLabel(cell) { return (cell.attrs && cell.attrs.label) || {}; }
    function attrLabelText(cell) {
        const l = attrLabel(cell);
        return l.text != null ? String(l.text) : '';
    }
    function attrLabelFill(cell) {
        return attrLabel(cell).fill || T.labelDefault;
    }
    function attrLabelSize(cell) {
        return attrLabel(cell).fontSize || 14;
    }

    /* Set of fill values the runtime uses to indicate a LIT lamp / occupied
     * track. Anything else (the OLD shape defaults #d4d4d4 / #3c4260, white,
     * grey, transparent, missing) is treated as OFF. */
    const LIT_FILLS = new Set([
        '#ff0000', '#ff2e2e', '#ffd400', '#22d142', '#00ff62', '#008633',
        'red', 'yellow', 'green', '#ff2828'
    ]);
    function isLit(colour) {
        if (!colour) return false;
        return LIT_FILLS.has(String(colour).toLowerCase().replace(/\s/g, ''));
    }

    /* ------------------------------------------------------------------------ *
     *  RENDERERS
     * ------------------------------------------------------------------------ */

    /* --- Track / rail strip (track.svg style) ------------------------------- */
    function renderRailStrip(x, cy, w, h) {
        h = Math.max(6, h);
        let svg = `<rect x="${x}" y="${cy - h / 2}" width="${w}" height="${h}" fill="${T.railBase}"/>`;
        svg += `<line x1="${x}" y1="${cy - h / 2 + 0.5}" x2="${x + w}" y2="${cy - h / 2 + 0.5}" stroke="${T.railEdge}" stroke-width="1"/>`;
        svg += `<line x1="${x}" y1="${cy + h / 2 - 0.5}" x2="${x + w}" y2="${cy + h / 2 - 0.5}" stroke="${T.railEdge}" stroke-width="1"/>`;
        const innerTop = cy - h / 2 + 1;
        const innerH = Math.max(1, h - 2);
        for (let i = 1; i + 1 <= w; i += 3) {
            svg += `<rect x="${x + i}" y="${innerTop}" width="1" height="${innerH}" fill="${T.sleeper}"/>`;
        }
        return svg;
    }

    /* --- Track / rail cell — green pill above the rail bed ------------------ */
    function renderTrack(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 60;
        const h = cell.size.height || 60;

        const labelAttrs = (cell.attrs && cell.attrs.label) || {};
        const labelTxt = labelAttrs.text != null ? String(labelAttrs.text) : '';
        const labelSize = +labelAttrs.fontSize || 13;

        const pathStroke = (cell.attrs && cell.attrs.path && cell.attrs.path.stroke) || '#3c4260';
        const occupied = isLit(pathStroke);
        const pillFill = occupied ? '#FF2E2E' : '#22A042';
        const pillStroke = occupied ? '#a01818' : '#1a8033';

        const cy = y + h / 2;

        let svg = `<g class="sip-asset sip-track" data-id="${cell.id}" data-type="${cell.type}">`;
        svg += `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="transparent"/>`;

        if (labelTxt) {
            const pillH = Math.max(20, labelSize + 8);
            const padX = 10;
            const approxTextW = Math.max(24, labelTxt.length * labelSize * 0.62);
            const pillW = approxTextW + 2 * padX;
            const px = x + (w - pillW) / 2;
            const py = cy - 9 - 6 - pillH;

            svg += `<rect x="${px}" y="${py}" width="${pillW}" height="${pillH}" ` +
                `rx="${pillH / 2}" ry="${pillH / 2}" ` +
                `fill="${pillFill}" stroke="${pillStroke}" stroke-width="1.2"/>`;
            svg += `<text x="${px + pillW / 2}" y="${py + pillH / 2 + labelSize / 3}" ` +
                `fill="#ffffff" font-family="${T.labelFont}" ` +
                `font-size="${labelSize}" font-weight="700" ` +
                `text-anchor="middle">${escapeXml(labelTxt)}</text>`;
        }

        svg += `</g>`;
        return svg;
    }

    /* --- Curved track (Track3 / Track4) ------------------------------------- */
    function renderTrackCurve(cell, dir) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width;
        const h = cell.size.height;
        const path = dir === 'right'
            ? `M ${x} ${y + h / 2}  C ${x + w * 0.3} ${y + h / 2}, ${x + w * 0.7} ${y + h / 2 + 18}, ${x + w} ${y + h / 2 + 18}`
            : `M ${x + w} ${y + h / 2}  C ${x + w * 0.7} ${y + h / 2}, ${x + w * 0.3} ${y + h / 2 + 18}, ${x} ${y + h / 2 + 18}`;
        return `<g class="sip-asset sip-track-curve" data-id="${cell.id}" data-type="${cell.type}">` +
            `<path d="${path}" fill="none" stroke="${T.railBase}" stroke-width="7" stroke-linecap="round"/>` +
            `<path d="${path}" fill="none" stroke="${T.sleeper}" stroke-width="1" stroke-dasharray="1,2"/>` +
            `</g>`;
    }

    /* --- Crossover diagonal ------------------------------------------------- */
    function renderCrossover(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width;
        const h = cell.size.height;
        const x1 = x, y1 = y;
        const x2 = x + w, y2 = y + h;
        const dx = x2 - x1, dy = y2 - y1;
        const len = Math.hypot(dx, dy);
        const ang = Math.atan2(dy, dx) * 180 / Math.PI;

        let svg = `<g class="sip-asset sip-crossover" data-id="${cell.id}" data-type="${cell.type}"`;
        svg += ` transform="translate(${x1} ${y1}) rotate(${ang})">`;
        svg += renderRailStrip(0, 0, len, 9);
        svg += `</g>`;
        return svg;
    }

    /* --- Point machine — smooth S-curve ------------------------------------ */
    function renderPointMachine(cell, mirror) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 60;
        const h = cell.size.height || 60;

        const bodyAttrs = (cell.attrs && cell.attrs.body) || {};
        const strokeC = bodyAttrs.stroke || '#3c4260';
        const bodyColor = isLit(strokeC)
            ? strokeC
            : (strokeC === '#3c4260' || strokeC === '#6a7596' ? '#8aa3c0' : strokeC);
        const bodySw = +bodyAttrs.strokeWidth || 4;

        const c1 = (cell.attrs && cell.attrs.circle1) || {};
        const indFill = c1.fill || '#d4d4d4';
        const indLit = isLit(indFill);

        const labelAttrs = (cell.attrs && cell.attrs.label) || {};
        const labelTxt = labelAttrs.text != null ? String(labelAttrs.text) : '';
        const labelFill = labelAttrs.fill && labelAttrs.fill !== 'transparent'
            ? labelAttrs.fill
            : '#FFC919';

        const sx = w / 79;
        const sy = h / 119;
        const px = (lx) => x + lx * sx;
        const py = (ly) => y + ly * sy;

        let d;
        if (mirror) {
            d = `M ${px(80)} ${py(119.91)} C ${px(31.59)} ${py(123.76)}, ${px(51.26)} ${py(1.10)}, ${px(0)} ${py(0)}`;
        } else {
            d = `M ${px(0)} ${py(118.93)} C ${px(52.67)} ${py(122.34)}, ${px(39.5)} ${py(-7.39)}, ${px(79)} ${py(0.33)}`;
        }

        let svg = `<g class="sip-asset sip-pm" data-id="${cell.id}" data-type="${cell.type}">`;
        svg += `<path d="${d}" fill="none" stroke="${bodyColor}" stroke-width="${bodySw + 3}" ` +
            `stroke-linecap="round" opacity="0.25"/>`;
        svg += `<path d="${d}" fill="none" stroke="${bodyColor}" stroke-width="${bodySw}" ` +
            `stroke-linecap="round"/>`;
        svg += `<path d="${d}" fill="none" stroke="white" stroke-width="1" ` +
            `stroke-linecap="round" opacity="0.35"/>`;

        const indCx = mirror ? px(54) : px(35);
        const indCy = mirror ? py(50) : py(54);
        const indR = 9;
        if (indLit) {
            svg += `<circle cx="${indCx}" cy="${indCy}" r="${indR + 5}" fill="${indFill}" opacity="0.18"/>`;
            svg += `<circle cx="${indCx}" cy="${indCy}" r="${indR + 2}" fill="${indFill}" opacity="0.35"/>`;
        }
        svg += `<circle cx="${indCx}" cy="${indCy}" r="${indR + 1}" fill="#0a0f1e" stroke="#22d3ee" stroke-width="1.2"/>`;
        svg += `<circle cx="${indCx}" cy="${indCy}" r="${indR}" ` +
            `fill="${indLit ? indFill : '#d4d4d4'}"/>`;
        if (indLit) {
            svg += `<ellipse cx="${indCx - indR * 0.35}" cy="${indCy - indR * 0.4}" ` +
                `rx="${indR * 0.32}" ry="${indR * 0.2}" fill="white" opacity="0.55"/>`;
        }

        if (labelTxt) {
            const lx = mirror ? indCx - (indR + 6) : indCx + (indR + 6);
            const anchor = mirror ? 'end' : 'start';
            const ly = indCy + 6;
            svg += `<text x="${lx}" y="${ly}" fill="#0a0f1e" stroke="#0a0f1e" stroke-width="3" ` +
                `font-family="${T.labelFont}" font-size="18" font-weight="800" ` +
                `text-anchor="${anchor}" paint-order="stroke">${escapeXml(labelTxt)}</text>`;
            svg += `<text x="${lx}" y="${ly}" fill="${labelFill}" ` +
                `font-family="${T.labelFont}" font-size="18" font-weight="800" ` +
                `text-anchor="${anchor}">${escapeXml(labelTxt)}</text>`;
        }
        svg += `</g>`;
        return svg;
    }

    /* --- Signal lamps ------------------------------------------------------- */

    /* ------------------------------------------------------------------------ *
     *  Stick / mast for signals & shunts
     *
     *  Real SIP yards show signals & shunts attached to their rail via an
     *  L-shaped connector:
     *      • a short vertical drop from the rail bed to the signal level
     *      • a short horizontal piece joining the back of the signal box
     *      • a small finial stem + cap on the far side of the head
     *  The L auto-flips depending on whether the cell sits above or below its
     *  nearest rail.
     *
     *  We need to know where the rails are. _railContext is set by
     *  renderRailLayer() before any per-cell render runs, so by the time
     *  renderStick() is called the rail y-centres are known.
     *
     *  Geometry inputs:
     *      headBox = {x, y, w, h}   — bounding box of the visible signal/shunt
     *                                  head (NOT the cell bounding box)
     *      backSide = 'left' | 'right' — which side of the head the post
     *                                    attaches to (i.e. the side facing
     *                                    away from the direction of travel)
     * ------------------------------------------------------------------------ */
    let _railContext = { bands: [] };

    function renderStick(headBox, backSide) {
        const bands = _railContext.bands || [];
        if (!bands.length) return '';

        const hcy = headBox.y + headBox.h / 2;
        // Find the rail band closest to this head vertically.
        let nearest = bands[0];
        let bestDist = Math.abs(bands[0].cy - hcy);
        for (let i = 1; i < bands.length; i++) {
            const d = Math.abs(bands[i].cy - hcy);
            if (d < bestDist) { nearest = bands[i]; bestDist = d; }
        }
        // If the head is too far from any rail (> 200 px), skip the stick.
        if (bestDist > 200) return '';

        const railCy = nearest.cy;
        // Determine orientation: is the head ABOVE or BELOW the rail?
        const headAbove = hcy < railCy;

        // The vertical drop runs from the rail edge to the level of the
        // back-of-box top/bottom — NOT all the way to the head centre.
        const railEdgeY = headAbove ? railCy - 9 : railCy + 9;   // rail bed half-height = 9
        const dropEndY = headAbove ? headBox.y - 4 : headBox.y + headBox.h + 4;

        // Horizontal joiner runs from the drop x over to the back side of the head.
        // backSide='right' means the post hangs on the right edge of the head.
        const backX = backSide === 'right' ? headBox.x + headBox.w + 4 : headBox.x - 4;
        // The drop sits at backX (no extra horizontal needed if backX == drop x),
        // but in practice we offset the drop slightly so the L is visible.
        const dropX = backX;

        const STK = '#7a7a7a';
        let svg = `<g class="sip-stick" pointer-events="none">`;
        // Vertical drop
        svg += `<line x1="${dropX}" y1="${railEdgeY}" x2="${dropX}" y2="${dropEndY}" ` +
            `stroke="${STK}" stroke-width="2.5" stroke-linecap="round"/>`;
        // Tiny horizontal stub joining the post to the head back edge
        const stubX2 = backSide === 'right' ? headBox.x + headBox.w : headBox.x;
        svg += `<line x1="${dropX}" y1="${dropEndY}" x2="${stubX2}" y2="${dropEndY}" ` +
            `stroke="${STK}" stroke-width="2.5" stroke-linecap="round"/>`;

        // Finial — small stem + cap dot on the FAR side of the head
        // (opposite the post). Mounted at the top edge if head is above rail,
        // bottom edge if head is below.
        const finialX = headBox.x + headBox.w / 2;
        const finialEdge = headAbove ? headBox.y : headBox.y + headBox.h;
        const finialTip = headAbove ? finialEdge - 10 : finialEdge + 10;
        const finialCap = headAbove ? finialEdge - 12 : finialEdge + 12;
        svg += `<line x1="${finialX}" y1="${finialEdge}" x2="${finialX}" y2="${finialTip}" ` +
            `stroke="${STK}" stroke-width="2" stroke-linecap="round"/>`;
        svg += `<circle cx="${finialX}" cy="${finialCap}" r="2.5" fill="${STK}"/>`;

        svg += `</g>`;
        return svg;
    }

    function renderSignalLamp(cell, _ignored, kind) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 30;
        const h = cell.size.height || 30;

        const c1 = (cell.attrs && cell.attrs.circle1) || {};
        const fillSaved = c1.fill || '#d4d4d4';
        const lit = isLit(fillSaved);

        /* No slot/tray rect — the visible "gray pill" behind a 3-lamp signal
           is now its own cell (examples.SignalBackground) that the user drops
           and sizes independently. A lamp is purely the circle, centred in
           its cell, scaled to ~70% of the smaller dimension. */
        const lcx = x + w / 2;
        const lcy = y + h / 2;
        const r = Math.max(4, Math.min(w, h) * 0.35);

        let svg = `<g class="sip-asset sip-signal" data-id="${cell.id}" data-type="${cell.type}">`;
        svg += `<circle cx="${lcx}" cy="${lcy}" r="${r + 1.5}" fill="none" stroke="#2a2a2a" stroke-width="1"/>`;

        if (lit) {
            let litColour;
            switch (kind) {
                case 'R': litColour = '#FF2E2E'; break;
                case 'G': litColour = '#22D142'; break;
                case 'Y': litColour = '#FFD400'; break;
                case 'X': litColour = '#FFD400'; break;
                default: litColour = fillSaved;
            }
            svg += `<circle cx="${lcx}" cy="${lcy}" r="${r + 4}" fill="${litColour}" opacity="0.18"/>`;
            svg += `<circle cx="${lcx}" cy="${lcy}" r="${r + 2}" fill="${litColour}" opacity="0.35"/>`;
            svg += `<circle cx="${lcx}" cy="${lcy}" r="${r}"     fill="${litColour}"/>`;
            svg += `<ellipse cx="${lcx - r * 0.35}" cy="${lcy - r * 0.4}" rx="${r * 0.35}" ry="${r * 0.22}" fill="white" opacity="0.45"/>`;
        } else {
            /* unlit / blank — the kind-specific symbol is faintly colored
               (rgba ~ 0.55 opacity of its aspect colour) so each lamp still
               identifies its aspect type at a glance, the way real signaling
               diagrams hint at lamp colour through the lens marking. */
            const KIND_TINT = {
                R: 'rgba(255, 46, 46, 0.62)',
                G: 'rgba(34, 209, 66, 0.62)',
                Y: 'rgba(255, 212, 0, 0.7)',
                X: 'rgba(255, 176, 32, 0.7)'
            };
            const sym = KIND_TINT[kind] || '#3a3a3a';
            svg += `<circle cx="${lcx}" cy="${lcy}" r="${r}" fill="#f4f4f4" stroke="#2a2a2a" stroke-width="1.5"/>`;
            svg += `<circle cx="${lcx}" cy="${lcy}" r="${r - 1.5}" fill="none" stroke="rgba(0,0,0,0.12)" stroke-width="1"/>`;
            if (kind === 'R') {
                svg += `<line x1="${lcx - r + 1}" y1="${lcy - 1.4}" x2="${lcx + r - 1}" y2="${lcy - 1.4}" stroke="${sym}" stroke-width="1.8" stroke-linecap="round"/>`;
                svg += `<line x1="${lcx - r + 1}" y1="${lcy + 1.4}" x2="${lcx + r - 1}" y2="${lcy + 1.4}" stroke="${sym}" stroke-width="1.8" stroke-linecap="round"/>`;
            } else if (kind === 'G') {
                svg += `<line x1="${lcx}" y1="${lcy - r + 1}" x2="${lcx}" y2="${lcy + r - 1}" stroke="${sym}" stroke-width="1.8" stroke-linecap="round"/>`;
            } else if (kind === 'Y') {
                const d = r * 0.72;
                svg += `<line x1="${lcx - d}" y1="${lcy - d}" x2="${lcx + d}" y2="${lcy + d}" stroke="${sym}" stroke-width="1.8" stroke-linecap="round"/>`;
            } else if (kind === 'X') {
                const d = r * 0.72;
                const off = 2.6;
                svg += `<line x1="${lcx - d}" y1="${lcy - d + off}" x2="${lcx + d}" y2="${lcy + d + off}" stroke="${sym}" stroke-width="1.8" stroke-linecap="round"/>`;
                svg += `<line x1="${lcx - d}" y1="${lcy - d - off}" x2="${lcx + d}" y2="${lcy + d - off}" stroke="${sym}" stroke-width="1.8" stroke-linecap="round"/>`;
            }
        }

        const lblAttr = (cell.attrs && cell.attrs.label) || {};
        const lblText = lblAttr.text != null ? String(lblAttr.text) : '';
        /* Same transparent-respect rule as before — keeps 3-aspect signals
           from stacking three labels on top of each other. */
        const lblIsVisible = !!lblText && lblAttr.fill !== 'transparent';
        if (lblIsVisible) {
            const lblFill = lblAttr.fill || 'rgba(220,228,245,0.85)';
            const lblSize = +lblAttr.fontSize || 14;
            const ly = lcy + r + lblSize + 4;
            svg += `<text x="${lcx}" y="${ly}" fill="#0a0f1e" stroke="#0a0f1e" stroke-width="3" ` +
                `font-family="${T.labelFont}" font-size="${lblSize}" font-weight="700" ` +
                `text-anchor="middle" paint-order="stroke">${escapeXml(lblText)}</text>`;
            svg += `<text x="${lcx}" y="${ly}" fill="${lblFill}" ` +
                `font-family="${T.labelFont}" font-size="${lblSize}" font-weight="700" ` +
                `text-anchor="middle">${escapeXml(lblText)}</text>`;
        }

        // Stick / mast — only on the labelled lamp (the visible head).
        if (lblIsVisible) {
            svg += renderStick({ x: x, y: y, w: w, h: h }, 'right');
        }

        svg += `</g>`;
        return svg;
    }

    /* --- Signal background (separate draggable tray) ----------------------- *
     *  Mirrors signal_Background.svg — a flat rounded gray pill at #606060.
     *  Used as the "tray" behind one or more lamp circles. Fully resizable;
     *  the renderer rescales rx with size so it always reads as a pill.
     * ----------------------------------------------------------------------- */
    function renderSignalBackground(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 54;
        const h = cell.size.height || 27;
        const rx = Math.min(6, Math.min(w, h) / 4);

        const lblAttr = (cell.attrs && cell.attrs.label) || {};
        const lblText = lblAttr.text != null ? String(lblAttr.text) : '';
        const lblVisible = !!lblText && lblAttr.fill !== 'transparent';

        let svg = `<g class="sip-asset sip-sig-bg" data-id="${cell.id}" data-type="${cell.type}">`;
        svg += `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" ry="${rx}" fill="#606060"/>`;
        if (lblVisible) {
            const fill = lblAttr.fill || T.labelDefault;
            const size = +lblAttr.fontSize || 12;
            svg += `<text x="${x + w / 2}" y="${y + h + size + 4}" fill="${fill}" ` +
                `font-family="${T.labelFont}" font-size="${size}" font-weight="600" ` +
                `text-anchor="middle">${escapeXml(lblText)}</text>`;
        }
        svg += `</g>`;
        return svg;
    }

    /* --- Signal (composite) ------------------------------------------------ *
     *  ONE cell that contains: background pill + N lamps + optional stand.
     *  Driven entirely by props (cell.attrs.signal) so the user adds/removes
     *  lamps by editing a single string.
     *
     *  attrs.signal = {
     *      lamps:        'BBB',     // string of lamp kinds — one char per lamp.
     *                               //   B = blank, R = red, Y = yellow,
     *                               //   G = green, X = double-yellow
     *      stand:        'bottom',  // 'none' | 'top' | 'bottom'
     *      standLength:  30         // px length of the vertical drop of the
     *                               // stand (the horizontal arm is fixed at
     *                               // half the signal width).
     *  }
     *
     *  Lamps are auto-spaced with EQUAL gaps around and between, scaled to
     *  fill the cell width.  Lamp diameter is derived from cell height so
     *  resizing the bounding box updates everything proportionally.
     * ----------------------------------------------------------------------- */
    const SIGNAL_LAMP_LIT = {
        R: '#FF2E2E', G: '#22D142', Y: '#FFD400', X: '#FFD400'
    };

    function renderSignalComposite(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 90;
        const h = cell.size.height || 24;

        /* props with safe defaults */
        const sigProps = (cell.attrs && cell.attrs.signal) || {};
        const lampsStr = typeof sigProps.lamps === 'string' && sigProps.lamps.length ? sigProps.lamps : 'BBB';
        const standMode = sigProps.stand || 'bottom';
        const standLen = Math.max(8, +sigProps.standLength || 30);

        /* lit-state map — same as old per-lamp model, but keyed by index.
           cell.attrs.lit could be 'R' (only red on) or 'RG' (red+green) or
           omitted (all off). */
        const litStr = typeof sigProps.lit === 'string' ? sigProps.lit.toUpperCase() : '';
        const litSet = {};
        for (let i = 0; i < litStr.length; i++) litSet[litStr[i]] = 1;

        const lamps = String(lampsStr).toUpperCase().split('');
        const n = Math.max(1, lamps.length);

        let svg = `<g class="sip-asset sip-signal-composite" data-id="${cell.id}" data-type="${cell.type}">`;

        /* 1. Stand — drawn FIRST so it sits behind the pill at the junction.
              Geometry follows the reference HTML's polyline connector style:
                 - Start at the signal centre on the chosen edge (top/bottom)
                 - Drop vertically by `standLength`
                 - If `standArm` is non-zero, then step horizontally by that
                   amount (positive = right, negative = left).  Final shape is
                   a clean L; matches the thin-stroke wireframe look of the
                   reference layouts. */
        if (standMode === 'top' || standMode === 'bottom') {
            const dir = standMode === 'bottom' ? 1 : -1;
            const standX = x + w / 2;
            const startY = dir > 0 ? y + h : y;
            const v1Y = startY + dir * standLen;
            const arm = +sigProps.standArm || 0;
            let path;
            if (arm === 0) {
                path = `M ${standX} ${startY} L ${standX} ${v1Y}`;
            } else {
                path = `M ${standX} ${startY} L ${standX} ${v1Y} L ${standX + arm} ${v1Y}`;
            }
            svg += `<path d="${path}" stroke="#b8b8b8" stroke-width="1.5" ` +
                `fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
        }

        /* 2. Background pill */
        const rx = Math.min(h / 2 - 1, 6);
        svg += `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" ry="${rx}" fill="#606060"/>`;

        /* 3. Lamps with equal padding (n+1 gaps total) */
        const lampD = Math.max(6, h - 6);                  // diameter (3px top/bottom pad)
        const totalLamps = n * lampD;
        const totalGap = Math.max(0, w - totalLamps);
        const gap = totalGap / (n + 1);
        const r = lampD / 2;

        for (let i = 0; i < n; i++) {
            const cx = x + gap * (i + 1) + lampD * i + r;
            const cy = y + h / 2;
            const kind = lamps[i];
            const isLitLamp = !!litSet[kind];
            const litColour = SIGNAL_LAMP_LIT[kind];

            if (isLitLamp && litColour) {
                svg += `<circle cx="${cx}" cy="${cy}" r="${r + 2.5}" fill="${litColour}" opacity="0.18"/>`;
                svg += `<circle cx="${cx}" cy="${cy}" r="${r + 1}"   fill="${litColour}" opacity="0.35"/>`;
                svg += `<circle cx="${cx}" cy="${cy}" r="${r}"       fill="${litColour}"/>`;
                svg += `<ellipse cx="${cx - r * 0.35}" cy="${cy - r * 0.4}" rx="${r * 0.35}" ry="${r * 0.22}" fill="white" opacity="0.45"/>`;
            } else {
                /* unlit / blank */
                svg += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="#f4f4f4" stroke="#2a2a2a" stroke-width="1.2"/>`;
                if (kind === 'R') {
                    svg += `<line x1="${cx - r + 1}" y1="${cy - 1.2}" x2="${cx + r - 1}" y2="${cy - 1.2}" stroke="#3a3a3a" stroke-width="1.4"/>`;
                    svg += `<line x1="${cx - r + 1}" y1="${cy + 1.2}" x2="${cx + r - 1}" y2="${cy + 1.2}" stroke="#3a3a3a" stroke-width="1.4"/>`;
                } else if (kind === 'G') {
                    svg += `<line x1="${cx}" y1="${cy - r + 1}" x2="${cx}" y2="${cy + r - 1}" stroke="#3a3a3a" stroke-width="1.4"/>`;
                } else if (kind === 'Y') {
                    const d = r * 0.72;
                    svg += `<line x1="${cx - d}" y1="${cy - d}" x2="${cx + d}" y2="${cy + d}" stroke="#3a3a3a" stroke-width="1.4"/>`;
                } else if (kind === 'X') {
                    const d = r * 0.72;
                    svg += `<line x1="${cx - d}" y1="${cy - d + 2.2}" x2="${cx + d}" y2="${cy + d + 2.2}" stroke="#3a3a3a" stroke-width="1.4"/>`;
                    svg += `<line x1="${cx - d}" y1="${cy - d - 2.2}" x2="${cx + d}" y2="${cy + d - 2.2}" stroke="#3a3a3a" stroke-width="1.4"/>`;
                }
                /* 'B' or anything else = plain blank circle */
            }
        }

        /* 4. Label — to the right of the signal by default */
        const lblAttr = (cell.attrs && cell.attrs.label) || {};
        const lblText = lblAttr.text != null ? String(lblAttr.text) : '';
        if (lblText && lblAttr.fill !== 'transparent') {
            const lblFill = lblAttr.fill || '#dcd7d7';
            const lblSize = +lblAttr.fontSize || 12;
            svg += `<text x="${x + w + 6}" y="${y + h / 2}" fill="${lblFill}" ` +
                `font-family="${T.labelFont}" font-size="${lblSize}" font-weight="700" ` +
                `text-anchor="start" dominant-baseline="central">${escapeXml(lblText)}</text>`;
        }

        svg += `</g>`;
        return svg;
    }

    /* --- Signal post -------------------------------------------------------- */
    function renderPost(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 100;
        const h = cell.size.height || 100;
        const labelTxt = attrLabelText(cell);
        const fill = attrLabel(cell).fill || T.siding;
        const size = attrLabel(cell).fontSize || 16;

        const padX = Math.max(10, Math.min(20, w * 0.15));
        const pillH = Math.max(22, Math.min(36, h * 0.45));
        const pillY = y + (h - pillH) / 2;

        let svg = `<g class="sip-asset sip-post" data-id="${cell.id}" data-type="${cell.type}">`;
        if (labelTxt) {
            svg += `<rect x="${x + padX}" y="${pillY}" width="${w - 2 * padX}" height="${pillH}" ` +
                `rx="${pillH / 2}" ry="${pillH / 2}" ` +
                `fill="rgba(34,211,238,0.08)" stroke="rgba(34,211,238,0.45)" stroke-width="1.2"/>`;
            svg += `<text x="${x + w / 2}" y="${pillY + pillH / 2 + size / 3}" fill="${fill}" ` +
                `font-family="${T.labelFont}" font-size="${size}" font-weight="700" ` +
                `text-anchor="middle">${escapeXml(labelTxt)}</text>`;
        } else {
            svg += `<rect x="${x + padX}" y="${pillY}" width="${w - 2 * padX}" height="${pillH}" ` +
                `rx="${pillH / 2}" ry="${pillH / 2}" ` +
                `fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="1" stroke-dasharray="3,3"/>`;
        }
        svg += `</g>`;
        return svg;
    }

    /* --- Shunt signal — three variants -------------------------------------- *
     *  Variant 1 (examples.Shaunt)  → dim TOP,  lit BL,  lit BR    [proceed]
     *  Variant 2 (examples.Shaunt2) → lit TOP,  dim BL,  lit BR    [diverge right]
     *  Variant 3 (examples.Shaunt3) → dim TOP,  dim BL,  dim BR    [blank / off]
     * ------------------------------------------------------------------------ */
    function renderShunt(cell, variant) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 25;
        const h = cell.size.height || 23;

        const bodyAttrs = (cell.attrs && cell.attrs.body) || {};
        const bodyFill = bodyAttrs.fill || '#5B6168';

        const labelAttrs = (cell.attrs && cell.attrs.label) || {};
        const labelTxt = labelAttrs.text != null ? String(labelAttrs.text) : '';

        const bw = Math.max(44, Math.min(w * 1.5, 64));
        const bh = bw * (23 / 25);
        const bx = x + (w - bw) / 2;
        const by = y + (h - bh) / 2;
        const sx = bw / 25;
        const sy = bh / 23;

        let svg = `<g class="sip-asset sip-shunt" data-id="${cell.id}" data-type="${cell.type}">`;

        if (isLit(bodyFill)) {
            svg += `<ellipse cx="${bx + bw / 2}" cy="${by + bh / 2}" rx="${bw * 0.7}" ry="${bh * 0.7}" ` +
                `fill="${bodyFill}" opacity="0.22"/>`;
        }

        const pathD = `M ${bx + 7.91188 * sx} ${by + 0.180471 * sy} ` +
            `C ${bx + 5.77625 * sx} ${by + 0.73042 * sy} ${bx + 4.28312 * sx} ${by + 2.8874 * sy} ${bx + 2.14 * sx} ${by + 8.52086 * sy} ` +
            `C ${bx + 0.436875 * sx} ${by + 12.9975 * sy} ${bx + 0.005625 * sx} ${by + 15.0254 * sy} ${bx + 0.003125 * sx} ${by + 18.5649 * sy} ` +
            `L ${bx} ${by + bh} L ${bx + bw / 2} ${by + bh} L ${bx + bw} ${by + bh} ` +
            `L ${bx + bw} ${by + 17.5017 * sy} L ${bx + bw} ${by + 12.0041 * sy} ` +
            `L ${bx + 21.7913 * sx} ${by + 9.09038 * sy} ` +
            `C ${bx + 20.0269 * sx} ${by + 7.48825 * sy} ${bx + 17.2844 * sx} ${by + 4.90306 * sy} ${bx + 15.6975 * sx} ${by + 3.34558 * sy} ` +
            `C ${bx + 12.8669 * sx} ${by + 0.567087 * sy} ${bx + 10.3638 * sx} ${by - 0.450839 * sy} ${bx + 7.91188 * sx} ${by + 0.180471 * sy} Z`;
        svg += `<path d="${pathD}" fill="#3a3e44"/>`;
        const inset = `<g transform="translate(${bx + bw / 2} ${by + bh / 2}) scale(0.96) translate(${-(bx + bw / 2)} ${-(by + bh / 2)})">` +
            `<path d="${pathD}" fill="${bodyFill}"/></g>`;
        svg += inset;

        // ── Indicator dots ──
        // dot positions:
        //   top  cx=9.5  cy=7.5
        //   BL   cx=7.5  cy=17.5
        //   BR   cx=17.5 cy=17.5
        // v1 = proceed         → top dim, BL lit, BR lit
        // v2 = diverge right   → top lit, BL dim, BR lit
        // v3 = blank / off     → all dim
        const dotR = Math.max(3.8, 3.8 * Math.min(sx, sy));
        const dotPositions = [
            { cx: bx + 9.5 * sx, cy: by + 7.5 * sy, lit: variant === 2 },                       // top
            { cx: bx + 7.5 * sx, cy: by + 17.5 * sy, lit: variant === 1 },                       // bottom-left
            { cx: bx + 17.5 * sx, cy: by + 17.5 * sy, lit: variant === 1 || variant === 2 }       // bottom-right
        ];
        for (const d of dotPositions) {
            if (d.lit) {
                svg += `<circle cx="${d.cx}" cy="${d.cy}" r="${dotR + 1.8}" fill="white" opacity="0.18"/>`;
                svg += `<circle cx="${d.cx}" cy="${d.cy}" r="${dotR}" fill="white"/>`;
                svg += `<ellipse cx="${d.cx - dotR * 0.35}" cy="${d.cy - dotR * 0.4}" rx="${dotR * 0.35}" ry="${dotR * 0.22}" fill="white" opacity="0.6"/>`;
            } else {
                svg += `<circle cx="${d.cx}" cy="${d.cy}" r="${dotR}" fill="white" fill-opacity="0.08" stroke="white" stroke-opacity="0.25" stroke-width="0.6"/>`;
            }
        }

        if (labelTxt) {
            const lFill = (labelAttrs.fill && labelAttrs.fill !== 'transparent')
                ? labelAttrs.fill
                : 'rgba(220,228,245,0.85)';
            const lx = bx + bw + 8;
            const ly = by + bh / 2 + 5;
            svg += `<text x="${lx}" y="${ly}" fill="#0a0f1e" stroke="#0a0f1e" stroke-width="3" ` +
                `font-family="${T.labelFont}" font-size="14" font-weight="700" ` +
                `dominant-baseline="middle" paint-order="stroke">${escapeXml(labelTxt)}</text>`;
            svg += `<text x="${lx}" y="${ly}" fill="${lFill}" ` +
                `font-family="${T.labelFont}" font-size="14" font-weight="700" ` +
                `dominant-baseline="middle">${escapeXml(labelTxt)}</text>`;
        }

        // Stand — drawn from cell.attrs.signal props, same model as the
        // composite signal so all stand-bearing elements behave consistently.
        // Falls back to the old auto-stick only when no signal props are set
        // (preserves legacy behaviour for data saved before this change).
        const sigProps = (cell.attrs && cell.attrs.signal) || null;
        if (sigProps && sigProps.stand && sigProps.stand !== 'none') {
            const standMode = sigProps.stand;
            const standLen = Math.max(8, +sigProps.standLength || 20);
            const arm = +sigProps.standArm || 0;
            const dir = standMode === 'bottom' ? 1 : -1;
            const sx0 = bx + bw / 2;
            const sy0 = dir > 0 ? by + bh : by;
            const v1Y = sy0 + dir * standLen;
            const path = (arm === 0)
                ? `M ${sx0} ${sy0} L ${sx0} ${v1Y}`
                : `M ${sx0} ${sy0} L ${sx0} ${v1Y} L ${sx0 + arm} ${v1Y}`;
            svg += `<path d="${path}" stroke="#b8b8b8" stroke-width="1.5" ` +
                `fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
        } else if (!sigProps) {
            // Legacy path: rail-snapping auto-stick for old saved shunts.
            svg += renderStick({ x: bx, y: by, w: bw, h: bh }, 'right');
        }

        svg += `</g>`;
        return svg;
    }

    /* --- Combined Signal + Shunt (S/SH44, S/C46 style) ---------------------- *
     *  3-aspect signal head (R/Y/G in one body) + shunt triangle right next
     *  to it, sharing one L-stick to the rail. Designed for ONE saved cell —
     *  no fragile multi-cell grouping logic needed.
     *
     *  The 3 lamp colours light up based on attrs.lit (e.g. 'R', 'Y', 'G',
     *  'X', or '' for all-off). Default = all three drawn unlit with marker
     *  strokes so the cell reads as "S/SH this is a combined signal" even
     *  when no telemetry has arrived yet.
     *
     *  Shunt variant is fixed at v1 (top dim, BL+BR lit) — same as the
     *  standalone Shaunt — because that's the most common combined pattern.
     * ------------------------------------------------------------------------ */
    function renderSignalShunt(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 200;
        const h = cell.size.height || 80;

        const litAttr = (cell.attrs && cell.attrs.lit) || '';

        const labelAttrs = (cell.attrs && cell.attrs.label) || {};
        const labelTxt = labelAttrs.text != null ? String(labelAttrs.text) : '';
        const labelFill = (labelAttrs.fill && labelAttrs.fill !== 'transparent')
            ? labelAttrs.fill : 'rgba(220,228,245,0.85)';
        const labelSize = +labelAttrs.fontSize || 14;

        // Layout inside the cell bounding box: signal box on the LEFT,
        // shunt triangle on the RIGHT, sharing the same y level.
        const sigW = 84;
        const sigH = 36;
        const shW = 44;
        const shH = shW * (23 / 25);
        const totalW = sigW + shW + 2;          // 2 = gap
        const innerY = y + (h - sigH) / 2;
        const startX = x + (w - totalW) / 2;
        const sigX = startX;
        const sigY = innerY;
        const shX = sigX + sigW + 2;
        const shY = innerY + (sigH - shH) / 2;

        let svg = `<g class="sip-asset sip-sigshunt" data-id="${cell.id}" data-type="${cell.type}">`;

        // ── 3-aspect signal head ──
        svg += `<rect x="${sigX}" y="${sigY}" width="${sigW}" height="${sigH}" rx="5" fill="#3a3a3a"/>`;
        svg += `<rect x="${sigX + 1}" y="${sigY + 1}" width="${sigW - 2}" height="${sigH - 2}" rx="4" fill="#606060"/>`;
        const lampDefs = [
            { kind: 'R', cx: sigX + 18, cy: sigY + sigH / 2 },
            { kind: 'Y', cx: sigX + 42, cy: sigY + sigH / 2 },
            { kind: 'G', cx: sigX + 66, cy: sigY + sigH / 2 }
        ];
        const litMap = { R: '#FF2E2E', Y: '#FFD400', G: '#22D142', X: '#FFD400' };
        for (const lamp of lampDefs) {
            const isLitLamp = litAttr === lamp.kind || (litAttr === 'X' && lamp.kind === 'Y');
            const r = 10;
            if (isLitLamp) {
                const col = litMap[lamp.kind] || '#FFD400';
                svg += `<circle cx="${lamp.cx}" cy="${lamp.cy}" r="${r + 4}" fill="${col}" opacity="0.18"/>`;
                svg += `<circle cx="${lamp.cx}" cy="${lamp.cy}" r="${r + 2}" fill="${col}" opacity="0.35"/>`;
                svg += `<circle cx="${lamp.cx}" cy="${lamp.cy}" r="${r}" fill="${col}"/>`;
                svg += `<ellipse cx="${lamp.cx - r * 0.35}" cy="${lamp.cy - r * 0.4}" rx="${r * 0.35}" ry="${r * 0.22}" fill="white" opacity="0.45"/>`;
            } else {
                svg += `<circle cx="${lamp.cx}" cy="${lamp.cy}" r="${r}" fill="#f4f4f4" stroke="#2a2a2a" stroke-width="1.2"/>`;
                // Marker
                if (lamp.kind === 'R') {
                    svg += `<line x1="${lamp.cx - r + 1}" y1="${lamp.cy - 1.4}" x2="${lamp.cx + r - 1}" y2="${lamp.cy - 1.4}" stroke="#3a3a3a" stroke-width="1.4"/>`;
                    svg += `<line x1="${lamp.cx - r + 1}" y1="${lamp.cy + 1.4}" x2="${lamp.cx + r - 1}" y2="${lamp.cy + 1.4}" stroke="#3a3a3a" stroke-width="1.4"/>`;
                } else if (lamp.kind === 'Y') {
                    const d = r * 0.72;
                    svg += `<line x1="${lamp.cx - d}" y1="${lamp.cy - d}" x2="${lamp.cx + d}" y2="${lamp.cy + d}" stroke="#3a3a3a" stroke-width="1.4"/>`;
                } else if (lamp.kind === 'G') {
                    svg += `<line x1="${lamp.cx}" y1="${lamp.cy - r + 1}" x2="${lamp.cx}" y2="${lamp.cy + r - 1}" stroke="#3a3a3a" stroke-width="1.4"/>`;
                }
            }
        }

        // ── Shunt triangle (v1: dim top, lit BL+BR) ──
        const sx = shW / 25;
        const sy = shH / 23;
        const pathD = `M ${shX + 7.91188 * sx} ${shY + 0.180471 * sy} ` +
            `C ${shX + 5.77625 * sx} ${shY + 0.73042 * sy} ${shX + 4.28312 * sx} ${shY + 2.8874 * sy} ${shX + 2.14 * sx} ${shY + 8.52086 * sy} ` +
            `C ${shX + 0.436875 * sx} ${shY + 12.9975 * sy} ${shX + 0.005625 * sx} ${shY + 15.0254 * sy} ${shX + 0.003125 * sx} ${shY + 18.5649 * sy} ` +
            `L ${shX} ${shY + shH} L ${shX + shW / 2} ${shY + shH} L ${shX + shW} ${shY + shH} ` +
            `L ${shX + shW} ${shY + 17.5017 * sy} L ${shX + shW} ${shY + 12.0041 * sy} ` +
            `L ${shX + 21.7913 * sx} ${shY + 9.09038 * sy} ` +
            `C ${shX + 20.0269 * sx} ${shY + 7.48825 * sy} ${shX + 17.2844 * sx} ${shY + 4.90306 * sy} ${shX + 15.6975 * sx} ${shY + 3.34558 * sy} ` +
            `C ${shX + 12.8669 * sx} ${shY + 0.567087 * sy} ${shX + 10.3638 * sx} ${shY - 0.450839 * sy} ${shX + 7.91188 * sx} ${shY + 0.180471 * sy} Z`;
        svg += `<path d="${pathD}" fill="#3a3e44"/>`;
        svg += `<g transform="translate(${shX + shW / 2} ${shY + shH / 2}) scale(0.96) translate(${-(shX + shW / 2)} ${-(shY + shH / 2)})">` +
            `<path d="${pathD}" fill="#5B6168"/></g>`;
        const dotR = Math.max(3.4, 3.4 * Math.min(sx, sy));
        const dots = [
            { cx: shX + 9.5 * sx, cy: shY + 7.5 * sy, lit: false },                  // top dim
            { cx: shX + 7.5 * sx, cy: shY + 17.5 * sy, lit: true },                   // BL lit
            { cx: shX + 17.5 * sx, cy: shY + 17.5 * sy, lit: true }                    // BR lit
        ];
        for (const d of dots) {
            if (d.lit) {
                svg += `<circle cx="${d.cx}" cy="${d.cy}" r="${dotR + 1.5}" fill="white" opacity="0.18"/>`;
                svg += `<circle cx="${d.cx}" cy="${d.cy}" r="${dotR}" fill="white"/>`;
                svg += `<ellipse cx="${d.cx - dotR * 0.35}" cy="${d.cy - dotR * 0.4}" rx="${dotR * 0.35}" ry="${dotR * 0.22}" fill="white" opacity="0.6"/>`;
            } else {
                svg += `<circle cx="${d.cx}" cy="${d.cy}" r="${dotR}" fill="white" fill-opacity="0.08" stroke="white" stroke-opacity="0.25" stroke-width="0.6"/>`;
            }
        }

        // ── L-stick to nearest rail ──
        // Use a bounding box that covers BOTH the signal head and the shunt
        // ── Stand ──
        // Drawn from cell.attrs.signal — same model as the Signal composite
        // and the three shunts, so the user adjusts stand mode / length /
        // arm in the inspector the same way for all stand-bearing types.
        // Legacy data without `attrs.signal` keeps the old rail-snapping
        // auto-stick so existing layouts don't regress.
        const sigStandProps = (cell.attrs && cell.attrs.signal) || null;
        const standHeadBox = { x: sigX, y: Math.min(sigY, shY), w: totalW, h: Math.max(sigH, shH) };
        if (sigStandProps && sigStandProps.stand && sigStandProps.stand !== 'none') {
            const standMode = sigStandProps.stand;
            const standLen = Math.max(8, +sigStandProps.standLength || 30);
            const arm = +sigStandProps.standArm || 0;
            const dir = standMode === 'bottom' ? 1 : -1;
            const sx0 = standHeadBox.x + standHeadBox.w / 2;
            const sy0 = dir > 0 ? standHeadBox.y + standHeadBox.h : standHeadBox.y;
            const v1Y = sy0 + dir * standLen;
            const path = (arm === 0)
                ? `M ${sx0} ${sy0} L ${sx0} ${v1Y}`
                : `M ${sx0} ${sy0} L ${sx0} ${v1Y} L ${sx0 + arm} ${v1Y}`;
            svg += `<path d="${path}" stroke="#b8b8b8" stroke-width="1.5" ` +
                `fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
        } else if (!sigStandProps) {
            svg += renderStick(standHeadBox, 'right');
        }

        // ── Label ──
        if (labelTxt) {
            const lx = sigX - 6;
            const ly = sigY + sigH / 2 + labelSize / 3;
            svg += `<text x="${lx}" y="${ly}" fill="#0a0f1e" stroke="#0a0f1e" stroke-width="3" ` +
                `font-family="${T.labelFont}" font-size="${labelSize}" font-weight="700" ` +
                `text-anchor="end" paint-order="stroke">${escapeXml(labelTxt)}</text>`;
            svg += `<text x="${lx}" y="${ly}" fill="${labelFill}" ` +
                `font-family="${T.labelFont}" font-size="${labelSize}" font-weight="700" ` +
                `text-anchor="end">${escapeXml(labelTxt)}</text>`;
        }

        svg += `</g>`;
        return svg;
    }

    /* --- Axle Counter ------------------------------------------------------- */
    function renderAxleCounter(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 100;
        const h = cell.size.height || 100;
        const labelTxt = attrLabelText(cell);

        const cx1 = x + w * 0.30, cy1 = y + h * 0.30;
        const cx2 = x + w * 0.70, cy2 = y + h * 0.70;
        const r = Math.max(5, Math.min(w, h) * 0.10);

        let svg = `<g class="sip-asset sip-ax" data-id="${cell.id}" data-type="${cell.type}">`;
        svg += `<line x1="${cx1}" y1="${cy1}" x2="${cx2}" y2="${cy2}" ` +
            `stroke="#8aa3c0" stroke-width="3" stroke-linecap="round"/>`;
        svg += `<line x1="${cx1}" y1="${cy1}" x2="${cx2}" y2="${cy2}" ` +
            `stroke="white" stroke-width="1" stroke-linecap="round" opacity="0.3"/>`;
        svg += `<circle cx="${cx1}" cy="${cy1}" r="${r + 1}" fill="#0a0f1e" stroke="#22d3ee" stroke-width="1.5"/>`;
        svg += `<circle cx="${cx1}" cy="${cy1}" r="${r - 2}" fill="#f4f4f4"/>`;
        svg += `<circle cx="${cx2}" cy="${cy2}" r="${r + 1}" fill="#0a0f1e" stroke="#22d3ee" stroke-width="1.5"/>`;
        svg += `<circle cx="${cx2}" cy="${cy2}" r="${r - 2}" fill="#f4f4f4"/>`;
        if (labelTxt) {
            const ly = cy2 + r + 18;
            svg += `<text x="${cx2}" y="${ly}" fill="#0a0f1e" stroke="#0a0f1e" stroke-width="3" ` +
                `font-family="${T.labelFont}" font-size="14" font-weight="700" ` +
                `text-anchor="middle" paint-order="stroke">${escapeXml(labelTxt)}</text>`;
            svg += `<text x="${cx2}" y="${ly}" fill="${T.labelDefault}" ` +
                `font-family="${T.labelFont}" font-size="14" font-weight="700" ` +
                `text-anchor="middle">${escapeXml(labelTxt)}</text>`;
        }
        svg += `</g>`;
        return svg;
    }

    /* --- Gate --------------------------------------------------------------- */
    function renderGate(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 100;
        const h = cell.size.height || 100;
        const labelTxt = attrLabelText(cell);
        const cx = x + w / 2;

        let svg = `<g class="sip-asset sip-gate" data-id="${cell.id}" data-type="${cell.type}">`;
        svg += `<line x1="${cx - 6}" y1="${y + 6}" x2="${cx - 6}" y2="${y + h - 6}" stroke="${T.signalBody}" stroke-width="2"/>`;
        svg += `<line x1="${cx + 6}" y1="${y + 6}" x2="${cx + 6}" y2="${y + h - 6}" stroke="${T.signalBody}" stroke-width="2"/>`;
        for (let i = 0; i < 4; i++) {
            const yy = y + 12 + i * (h - 24) / 3;
            svg += `<line x1="${cx - 18}" y1="${yy}" x2="${cx + 18}" y2="${yy}" stroke="${T.signalBody}" stroke-width="1.5"/>`;
        }
        if (labelTxt) {
            svg += `<text x="${cx}" y="${y + h + 14}" fill="${T.labelDefault}" ` +
                `font-family="${T.labelFont}" font-size="12" font-weight="700" text-anchor="middle">${escapeXml(labelTxt)}</text>`;
        }
        svg += `</g>`;
        return svg;
    }

    /* --- Bus Bar ------------------------------------------------------------ */
    function renderBusBar(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 100;
        const h = cell.size.height || 25;
        const labelTxt = attrLabelText(cell);
        const fill = attrLabel(cell).fill || T.bbLabel;

        let svg = `<g class="sip-asset sip-bb" data-id="${cell.id}" data-type="${cell.type}">`;
        svg += `<rect x="${x}" y="${y + h / 2 - 4}" width="${Math.max(40, w)}" height="8" rx="2" fill="${T.busBar}"/>`;
        if (labelTxt) {
            svg += `<text x="${x + Math.max(40, w) / 2}" y="${y + h / 2 + 22}" fill="${fill}" ` +
                `font-family="${T.labelFont}" font-size="12" font-weight="800" text-anchor="middle">${escapeXml(labelTxt)}</text>`;
        }
        svg += `</g>`;
        return svg;
    }

    /* --- Arrow -------------------------------------------------------------- */
    function renderArrow(cell, dir) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 100;
        const h = cell.size.height || 100;
        const cy = y + h / 2;
        const labelTxt = attrLabelText(cell);

        const pts = (dir === 'right')
            ? `${x + 4},${cy - 4} ${x + w - 14},${cy - 4} ${x + w - 14},${cy - 10} ${x + w - 4},${cy} ${x + w - 14},${cy + 10} ${x + w - 14},${cy + 4} ${x + 4},${cy + 4}`
            : `${x + w - 4},${cy - 4} ${x + 14},${cy - 4} ${x + 14},${cy - 10} ${x + 4},${cy} ${x + 14},${cy + 10} ${x + 14},${cy + 4} ${x + w - 4},${cy + 4}`;
        let svg = `<g class="sip-asset sip-arrow" data-id="${cell.id}" data-type="${cell.type}">`;
        svg += `<polygon points="${pts}" fill="${T.signalBody}"/>`;
        if (labelTxt) {
            svg += `<text x="${x + w / 2}" y="${y + h + 14}" fill="${T.labelDefault}" ` +
                `font-family="${T.labelFont}" font-size="12" font-weight="700" text-anchor="middle">${escapeXml(labelTxt)}</text>`;
        }
        svg += `</g>`;
        return svg;
    }

    /* --- Top/Bottom route line --------------------------------------------- */
    function renderTopLine(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 37;
        const h = cell.size.height || 49;
        return `<g class="sip-asset sip-line" data-id="${cell.id}" data-type="${cell.type}">` +
            `<path d="M ${x + 2} ${y + h} L ${x + 2} ${y + 4} Q ${x + 2} ${y + 2}, ${x + 4} ${y + 2} L ${x + w} ${y + 2}" ` +
            `stroke="${T.routeLine}" stroke-width="4" fill="none"/>` +
            `</g>`;
    }
    function renderBottomLine(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 37;
        const h = cell.size.height || 56;
        return `<g class="sip-asset sip-line" data-id="${cell.id}" data-type="${cell.type}">` +
            `<path d="M ${x + w - 2} ${y} L ${x + w - 2} ${y + h - 4} Q ${x + w - 2} ${y + h - 2}, ${x + w - 4} ${y + h - 2} L ${x} ${y + h - 2}" ` +
            `stroke="${T.routeLine}" stroke-width="4" fill="none"/>` +
            `</g>`;
    }

    /* --- Track breaker (insulated rail joint) ------------------------------ *
     *  A short vertical bar that marks the boundary between two track
     *  circuits / sections. Drawn perpendicular to the rail so it remains
     *  visible against both the rail body and any section pill.
     *
     *  Geometry:                    ┃   ← yellow bar
     *      ───────────────●────────────── rail
     *                    cx,cy
     * -------------------------------------------------------------------- */
    function renderTrackBreaker(cell) {
        const x = cell.position.x;
        const y = cell.position.y;
        const w = cell.size.width || 12;
        const h = cell.size.height || 26;
        const cx = x + w / 2;
        const cy = y + h / 2;
        const barH = Math.max(18, h);
        const barW = 3;

        const lblAttr = (cell.attrs && cell.attrs.label) || {};
        const lblText = lblAttr.text != null ? String(lblAttr.text) : '';
        const lblVisible = !!lblText && lblAttr.fill !== 'transparent';

        let svg = `<g class="sip-asset sip-breaker" data-id="${cell.id}" data-type="${cell.type}">`;
        // dark backing makes the bar pop even when it lands on top of a pill
        svg += `<rect x="${cx - barW / 2 - 1}" y="${cy - barH / 2 - 1}" width="${barW + 2}" height="${barH + 2}" fill="#0a0f1e"/>`;
        svg += `<rect x="${cx - barW / 2}"     y="${cy - barH / 2}"     width="${barW}"     height="${barH}"     fill="#FFD400"/>`;
        if (lblVisible) {
            const fill = lblAttr.fill || '#dcd7d7';
            const sz = +lblAttr.fontSize || 11;
            svg += `<text x="${cx}" y="${cy + barH / 2 + sz + 2}" fill="${fill}" ` +
                `font-family="${T.labelFont}" font-size="${sz}" font-weight="600" ` +
                `text-anchor="middle">${escapeXml(lblText)}</text>`;
        }
        svg += `</g>`;
        return svg;
    }

    /* ------------------------------------------------------------------------ *
     *  ASSET REGISTRY
     * ------------------------------------------------------------------------ */
    const ASSETS = {
        'examples.Track': {
            label: 'Track (short)', group: 'track',
            size: { width: 300, height: 100 },
            attrs: {
                path: { type: 'path', fill: 'none', stroke: '#6a7596', strokeWidth: 3, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: renderTrack,
            icon: function () {
                return `<svg viewBox="0 0 60 24"><rect x="2" y="10" width="56" height="4" fill="${T.railBase}"/>` +
                    `<line x1="2" y1="10" x2="58" y2="10" stroke="#fff" stroke-width="0.4"/>` +
                    `<line x1="2" y1="14" x2="58" y2="14" stroke="#fff" stroke-width="0.4"/>` +
                    Array.from({ length: 18 }, (_, i) => `<rect x="${4 + i * 3}" y="11" width="1" height="2" fill="${T.sleeper}"/>`).join('') +
                    `</svg>`;
            }
        },
        'examples.Track1': {
            label: 'Track (long)', group: 'track',
            size: { width: 200, height: 100 },
            attrs: {
                path: { type: 'path', fill: 'none', stroke: '#6a7596', strokeWidth: 3, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: renderTrack,
            icon: function () { return ASSETS['examples.Track'].icon(); }
        },
        'examples.Track2': {
            label: 'Track (extra-long)', group: 'track',
            size: { width: 400, height: 100 },
            attrs: {
                path: { type: 'path', fill: 'none', stroke: '#6a7596', strokeWidth: 3, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: renderTrack,
            icon: function () { return ASSETS['examples.Track'].icon(); }
        },
        'examples.Track3': {
            hidden: true, label: 'Curve (left)', group: 'point',
            size: { width: 100, height: 100 },
            attrs: {
                path: { type: 'path', fill: T.railBase, stroke: 'none', strokeWidth: 0, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: function (cell) { return renderTrackCurve(cell, 'left'); },
            icon: function () {
                return `<svg viewBox="0 0 60 24"><path d="M 2 8 C 20 8, 40 18, 58 18" stroke="${T.railBase}" stroke-width="5" fill="none" stroke-linecap="round"/></svg>`;
            }
        },
        'examples.Track4': {
            hidden: true, label: 'Curve (right)', group: 'point',
            size: { width: 100, height: 100 },
            attrs: {
                path: { type: 'path', fill: T.railBase, stroke: 'none', strokeWidth: 0, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: function (cell) { return renderTrackCurve(cell, 'right'); },
            icon: function () {
                return `<svg viewBox="0 0 60 24"><path d="M 58 8 C 40 8, 20 18, 2 18" stroke="${T.railBase}" stroke-width="5" fill="none" stroke-linecap="round"/></svg>`;
            }
        },
        'examples.TrackBreaker': {
            hidden: true, label: 'Track Breaker', group: 'track',
            size: { width: 12, height: 26 },
            attrs: {
                label: { text: '', fill: 'transparent', fontSize: 11, fontWeight: 'bold' }
            },
            render: renderTrackBreaker,
            icon: function () {
                return `<svg viewBox="0 0 60 24">` +
                    `<rect x="2"  y="10" width="56" height="4" fill="${T.railBase}"/>` +
                    `<line x1="2"  y1="10" x2="58" y2="10" stroke="#fff" stroke-width="0.4"/>` +
                    `<line x1="2"  y1="14" x2="58" y2="14" stroke="#fff" stroke-width="0.4"/>` +
                    Array.from({ length: 18 }, (_, i) => `<rect x="${4 + i * 3}" y="11" width="1" height="2" fill="${T.sleeper}"/>`).join('') +
                    `<rect x="28" y="3"  width="4" height="18" fill="#0a0f1e"/>` +
                    `<rect x="29" y="4"  width="2" height="16" fill="#FFD400"/>` +
                    `</svg>`;
            }
        },
        'examples.PointMachine': {
            label: 'Point Machine', group: 'point',
            size: { width: 100, height: 60 },
            attrs: {
                body: { type: 'path', fill: 'none', stroke: '#6a7596', strokeWidth: 3, pointerEvents: 'bounding-box' },
                circle1: { cx: 35, cy: 54, r: 6, stroke: 'black', fill: '#d4d4d4' },
                label: { text: '', fill: T.labelHi, fontSize: 14, fontWeight: 'bold' }
            },
            render: function (cell) { return renderPointMachine(cell, false); },
            icon: function () {
                return `<svg viewBox="0 0 60 28">` +
                    `<path d="M 6 20 L 54 4" stroke="${T.railBase}" stroke-width="4"/>` +
                    `<path d="M 30 10 L 30 22 L 42 22 L 42 14 Z" fill="${T.pmBody}"/>` +
                    `<circle cx="33" cy="20" r="1.6" fill="${T.pmDot}"/>` +
                    `<circle cx="39" cy="20" r="1.6" fill="${T.pmDot}"/>` +
                    `<circle cx="36" cy="16" r="1.6" fill="${T.pmDot}"/>` +
                    `</svg>`;
            }
        },
        'examples.PointMachine1': {
            label: 'Point Machine (mirror)', group: 'point',
            size: { width: 100, height: 60 },
            attrs: {
                body: { type: 'path', fill: 'none', stroke: '#6a7596', strokeWidth: 3, pointerEvents: 'bounding-box' },
                circle1: { cx: 54, cy: 50, r: 6, stroke: 'black', fill: '#d4d4d4' },
                label: { text: '', fill: T.labelHi, fontSize: 14, fontWeight: 'bold' }
            },
            render: function (cell) { return renderPointMachine(cell, true); },
            icon: function () {
                return `<svg viewBox="0 0 60 28">` +
                    `<path d="M 54 20 L 6 4" stroke="${T.railBase}" stroke-width="4"/>` +
                    `<path d="M 18 10 L 18 22 L 30 22 L 30 14 Z" fill="${T.pmBody}"/>` +
                    `<circle cx="21" cy="20" r="1.6" fill="${T.pmDot}"/>` +
                    `<circle cx="27" cy="20" r="1.6" fill="${T.pmDot}"/>` +
                    `<circle cx="24" cy="16" r="1.6" fill="${T.pmDot}"/>` +
                    `</svg>`;
            }
        },
        'examples.Signal': {
            label: 'Signal', group: 'signal',
            size: { width: 90, height: 24 },
            attrs: {
                signal: { lamps: 'BBB', stand: 'bottom', standLength: 30, lit: '' },
                label: { text: '', fill: 'transparent', fontSize: 12, fontWeight: 'bold' }
            },
            render: renderSignalComposite,
            icon: function () {
                /* Toolbox tile preview — 3 blank lamps in a pill with a tiny stand. */
                return `<svg viewBox="0 0 60 30" xmlns="http://www.w3.org/2000/svg">` +
                    `<line x1="30" y1="20" x2="30" y2="28" stroke="#b8b8b8" stroke-width="1.5" stroke-linecap="round"/>` +
                    `<rect x="4"  y="8" width="52" height="12" rx="3" ry="3" fill="#606060"/>` +
                    `<circle cx="13" cy="14" r="3.6" fill="#f4f4f4" stroke="#2a2a2a" stroke-width="0.6"/>` +
                    `<circle cx="30" cy="14" r="3.6" fill="#f4f4f4" stroke="#2a2a2a" stroke-width="0.6"/>` +
                    `<circle cx="47" cy="14" r="3.6" fill="#f4f4f4" stroke="#2a2a2a" stroke-width="0.6"/>` +
                    `</svg>`;
            }
        },
        'examples.SignalBackground': {
            hidden: true, label: 'Signal Background', group: 'signal',
            size: { width: 54, height: 27 },
            attrs: {
                body: { type: 'rect', fill: '#606060', stroke: 'none', strokeWidth: 0 },
                label: { text: '', fill: 'transparent', fontSize: 12, fontWeight: 'bold' }
            },
            render: renderSignalBackground,
            icon: function () {
                return `<svg viewBox="0 0 60 24">` +
                    `<rect x="3" y="6"  width="54" height="12" rx="3" ry="3" fill="#606060"/>` +
                    `<circle cx="13" cy="12" r="3.5" fill="#f4f4f4" stroke="#2a2a2a" stroke-width="0.8"/>` +
                    `<circle cx="30" cy="12" r="3.5" fill="#f4f4f4" stroke="#2a2a2a" stroke-width="0.8"/>` +
                    `<circle cx="47" cy="12" r="3.5" fill="#f4f4f4" stroke="#2a2a2a" stroke-width="0.8"/>` +
                    `</svg>`;
            }
        },
        'examples.Signald90': {
            label: 'Signal — Red (RG)', group: 'signal',
            size: { width: 30, height: 30 },
            attrs: {
                circle1: { cx: 10, cy: 10, r: 10, stroke: 'black', fill: '#d4d4d4' },
                path1: { type: 'path', fill: 'none', stroke: '#6a7596', strokeWidth: 1, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 11, fontWeight: 'bold' }
            },
            render: function (cell) { return renderSignalLamp(cell, null, 'R'); },
            icon: function () { return signalLampIcon(T.lampRed, 'R'); }
        },
        'examples.Signal90': {
            label: 'Signal — Green (DG)', group: 'signal',
            size: { width: 30, height: 30 },
            attrs: {
                circle1: { cx: 10, cy: 10, r: 10, stroke: 'black', fill: '#d4d4d4' },
                path1: { type: 'path', fill: 'none', stroke: '#6a7596', strokeWidth: 1, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 11, fontWeight: 'bold' }
            },
            render: function (cell) { return renderSignalLamp(cell, null, 'G'); },
            icon: function () { return signalLampIcon(T.lampGreen, 'G'); }
        },
        'examples.Signal45': {
            label: 'Signal — Yellow (HG)', group: 'signal',
            size: { width: 30, height: 30 },
            attrs: {
                circle1: { cx: 10, cy: 10, r: 10, stroke: 'black', fill: '#d4d4d4' },
                path1: { type: 'path', fill: 'none', stroke: '#6a7596', strokeWidth: 1, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 11, fontWeight: 'bold' }
            },
            render: function (cell) { return renderSignalLamp(cell, null, 'Y'); },
            icon: function () { return signalLampIcon(T.lampYellow, 'Y'); }
        },
        'examples.Signald45': {
            label: 'Signal — Double Yellow (HHG)', group: 'signal',
            size: { width: 30, height: 30 },
            attrs: {
                circle1: { cx: 10, cy: 10, r: 10, stroke: 'black', fill: '#d4d4d4' },
                path1: { type: 'path', fill: 'none', stroke: '#6a7596', strokeWidth: 1, pointerEvents: 'bounding-box' },
                path2: { type: 'path', fill: 'none', stroke: '#6a7596', strokeWidth: 1, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 11, fontWeight: 'bold' }
            },
            render: function (cell) { return renderSignalLamp(cell, null, 'X'); },
            icon: function () { return signalLampIcon(T.lampYellow, 'X'); }
        },
        'examples.Post': {
            label: 'Signal Post / Label', group: 'signal',
            size: { width: 60, height: 60 },
            attrs: {
                label: { text: 'NEW', fill: T.siding, fontSize: 16, fontWeight: 'bold' }
            },
            render: renderPost,
            icon: function () {
                return `<svg viewBox="0 0 60 24"><text x="30" y="16" text-anchor="middle" font-family="${T.labelFont}" font-size="12" fill="${T.siding}" font-weight="700">S18</text></svg>`;
            }
        },
        'examples.Post1': {
            label: 'Signal Post (alt)', group: 'signal',
            size: { width: 60, height: 60 },
            attrs: {
                label: { text: 'NEW', fill: T.siding, fontSize: 16, fontWeight: 'bold' }
            },
            render: renderPost,
            icon: function () { return ASSETS['examples.Post'].icon(); }
        },
        'examples.Shaunt': {
            label: 'Shunt Signal', group: 'shunt',
            size: { width: 30, height: 30 },
            attrs: {
                signal: { stand: 'bottom', standLength: 22, standArm: 0 },
                body: { type: 'Path', fill: 'none', stroke: '#6a7596', strokeWidth: 3, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: function (cell) { return renderShunt(cell, 1); },
            icon: function () {
                // v1 — top dim, BL lit, BR lit
                return `<svg viewBox="0 0 50 28">` +
                    `<g transform="translate(12 2) scale(0.96)">` +
                    `<path d="M 7.9 0.2 C 5.8 0.7 4.3 2.9 2.1 8.5 C 0.4 13 0 15 0 18.6 L 0 23 L 25 23 L 25 17.5 L 25 12 L 21.8 9.1 C 20 7.5 17.3 4.9 15.7 3.3 C 12.9 0.6 10.4 -0.5 7.9 0.2 Z" fill="#3a3e44"/>` +
                    `<g transform="translate(12.5 11.5) scale(0.96) translate(-12.5 -11.5)">` +
                    `<path d="M 7.9 0.2 C 5.8 0.7 4.3 2.9 2.1 8.5 C 0.4 13 0 15 0 18.6 L 0 23 L 25 23 L 25 17.5 L 25 12 L 21.8 9.1 C 20 7.5 17.3 4.9 15.7 3.3 C 12.9 0.6 10.4 -0.5 7.9 0.2 Z" fill="${T.shuntBody}"/>` +
                    `</g></g>` +
                    `<circle cx="23.4" cy="9.2" r="2" fill="white" fill-opacity="0.1"/>` +
                    `<circle cx="19.5" cy="19.5" r="2" fill="white"/>` +
                    `<circle cx="27.4" cy="19.5" r="2" fill="white"/>` +
                    `</svg>`;
            }
        },
        'examples.Shaunt2': {
            label: 'Shunt Signal (alt)', group: 'shunt',
            size: { width: 30, height: 30 },
            attrs: {
                signal: { stand: 'bottom', standLength: 22, standArm: 0 },
                body: { type: 'Path', fill: 'none', stroke: '#6a7596', strokeWidth: 3, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: function (cell) { return renderShunt(cell, 2); },
            icon: function () {
                // v2 — top lit, BL DIM, BR lit  (right two lit, swapped from before)
                return `<svg viewBox="0 0 50 28">` +
                    `<g transform="translate(12 2) scale(0.96)">` +
                    `<path d="M 7.9 0.2 C 5.8 0.7 4.3 2.9 2.1 8.5 C 0.4 13 0 15 0 18.6 L 0 23 L 25 23 L 25 17.5 L 25 12 L 21.8 9.1 C 20 7.5 17.3 4.9 15.7 3.3 C 12.9 0.6 10.4 -0.5 7.9 0.2 Z" fill="#3a3e44"/>` +
                    `<g transform="translate(12.5 11.5) scale(0.96) translate(-12.5 -11.5)">` +
                    `<path d="M 7.9 0.2 C 5.8 0.7 4.3 2.9 2.1 8.5 C 0.4 13 0 15 0 18.6 L 0 23 L 25 23 L 25 17.5 L 25 12 L 21.8 9.1 C 20 7.5 17.3 4.9 15.7 3.3 C 12.9 0.6 10.4 -0.5 7.9 0.2 Z" fill="${T.shuntBody}"/>` +
                    `</g></g>` +
                    `<circle cx="23.4" cy="9.2" r="2" fill="white"/>` +
                    `<circle cx="19.5" cy="19.5" r="2" fill="white" fill-opacity="0.1"/>` +
                    `<circle cx="27.4" cy="19.5" r="2" fill="white"/>` +
                    `</svg>`;
            }
        },
        'examples.Shaunt3': {
            label: 'Shunt Signal (blank)', group: 'shunt',
            size: { width: 30, height: 30 },
            attrs: {
                signal: { stand: 'bottom', standLength: 22, standArm: 0 },
                body: { type: 'Path', fill: 'none', stroke: '#6a7596', strokeWidth: 3, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: function (cell) { return renderShunt(cell, 3); },
            icon: function () {
                // v3 — all three dim
                return `<svg viewBox="0 0 50 28">` +
                    `<g transform="translate(12 2) scale(0.96)">` +
                    `<path d="M 7.9 0.2 C 5.8 0.7 4.3 2.9 2.1 8.5 C 0.4 13 0 15 0 18.6 L 0 23 L 25 23 L 25 17.5 L 25 12 L 21.8 9.1 C 20 7.5 17.3 4.9 15.7 3.3 C 12.9 0.6 10.4 -0.5 7.9 0.2 Z" fill="#3a3e44"/>` +
                    `<g transform="translate(12.5 11.5) scale(0.96) translate(-12.5 -11.5)">` +
                    `<path d="M 7.9 0.2 C 5.8 0.7 4.3 2.9 2.1 8.5 C 0.4 13 0 15 0 18.6 L 0 23 L 25 23 L 25 17.5 L 25 12 L 21.8 9.1 C 20 7.5 17.3 4.9 15.7 3.3 C 12.9 0.6 10.4 -0.5 7.9 0.2 Z" fill="${T.shuntBody}"/>` +
                    `</g></g>` +
                    `<circle cx="23.4" cy="9.2" r="2" fill="white" fill-opacity="0.1"/>` +
                    `<circle cx="19.5" cy="19.5" r="2" fill="white" fill-opacity="0.1"/>` +
                    `<circle cx="27.4" cy="19.5" r="2" fill="white" fill-opacity="0.1"/>` +
                    `</svg>`;
            }
        },
        'examples.SignalShunt': {
            label: 'Signal + Shunt (combined)', group: 'signal',
            size: { width: 200, height: 80 },
            attrs: {
                signal: { stand: 'bottom', standLength: 30, standArm: 0 },
                lit: '',            // '' | 'R' | 'Y' | 'G' | 'X'
                body: { type: 'Path', fill: 'none', stroke: '#6a7596', strokeWidth: 3, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: renderSignalShunt,
            icon: function () {
                return `<svg viewBox="0 0 80 28">` +
                    `<rect x="2" y="4" width="46" height="20" rx="3" fill="#3a3a3a"/>` +
                    `<rect x="3" y="5" width="44" height="18" rx="2" fill="#606060"/>` +
                    `<circle cx="12" cy="14" r="5" fill="#FF2E2E"/>` +
                    `<circle cx="25" cy="14" r="5" fill="#FFD400"/>` +
                    `<circle cx="38" cy="14" r="5" fill="#22D142"/>` +
                    // mini shunt triangle
                    `<path d="M 56 7 L 68 7 Q 76 7 78 14 Q 76 22 68 22 L 56 22 Q 55 22 55 21 L 55 8 Q 55 7 56 7 Z" fill="#5B6168"/>` +
                    `<circle cx="60" cy="12" r="1.8" fill="white"/>` +
                    `<circle cx="68" cy="12" r="1.8" fill="white"/>` +
                    `<circle cx="64" cy="18" r="1.8" fill="white"/>` +
                    `</svg>`;
            }
        },
        'examples.AxleCounter': {
            label: 'Axle Counter', group: 'shunt',
            size: { width: 30, height: 30 },
            attrs: {
                path: { type: 'path', fill: 'none', stroke: '#6a7596', strokeWidth: 3, pointerEvents: 'bounding-box' },
                circle1: { cx: 36, cy: 65, r: 5, stroke: '#6a7596', fill: 'white' },
                circle2: { cx: 0, cy: 100, r: 5, stroke: '#6a7596', fill: 'white' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: renderAxleCounter,
            icon: function () {
                return `<svg viewBox="0 0 50 24">` +
                    `<line x1="35" y1="6" x2="10" y2="20" stroke="${T.signalBody}" stroke-width="2"/>` +
                    `<circle cx="35" cy="6" r="3" fill="${T.lampOff}" stroke="${T.signalBody}"/>` +
                    `<circle cx="10" cy="20" r="3" fill="${T.lampOff}" stroke="${T.signalBody}"/>` +
                    `</svg>`;
            }
        },
        'examples.Gate': {
            label: 'Gate', group: 'shunt',
            size: { width: 60, height: 60 },
            attrs: {
                body: { type: 'Path', fill: 'none', stroke: '#6a7596', strokeWidth: 1, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: renderGate,
            icon: function () {
                return `<svg viewBox="0 0 50 24">` +
                    `<line x1="22" y1="4" x2="22" y2="20" stroke="${T.signalBody}" stroke-width="2"/>` +
                    `<line x1="28" y1="4" x2="28" y2="20" stroke="${T.signalBody}" stroke-width="2"/>` +
                    `<line x1="14" y1="8"  x2="36" y2="8"  stroke="${T.signalBody}" stroke-width="1"/>` +
                    `<line x1="14" y1="12" x2="36" y2="12" stroke="${T.signalBody}" stroke-width="1"/>` +
                    `<line x1="14" y1="16" x2="36" y2="16" stroke="${T.signalBody}" stroke-width="1"/>` +
                    `</svg>`;
            }
        },
        'examples.BusBar': {
            label: 'Bus Bar', group: 'busbar',
            size: { width: 100, height: 25 },
            attrs: {
                label: { text: 'B1', fill: T.bbLabel, fontSize: 14, fontWeight: 'bold' }
            },
            render: renderBusBar,
            icon: function () {
                return `<svg viewBox="0 0 60 24"><rect x="6" y="8" width="48" height="6" rx="2" fill="${T.busBar}"/>` +
                    `<text x="30" y="22" text-anchor="middle" font-family="${T.labelFont}" font-size="9" font-weight="800" fill="${T.bbLabel}">B1</text></svg>`;
            }
        },
        'examples.RightArrow': {
            label: 'Arrow →', group: 'busbar',
            size: { width: 100, height: 30 },
            attrs: {
                path: { type: 'path', fill: T.signalBody, stroke: T.signalBody, strokeWidth: 0, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: function (cell) { return renderArrow(cell, 'right'); },
            icon: function () {
                return `<svg viewBox="0 0 60 24"><polygon points="6,10 42,10 42,6 54,12 42,18 42,14 6,14" fill="${T.signalBody}"/></svg>`;
            }
        },
        'examples.LeftArrow': {
            label: 'Arrow ←', group: 'busbar',
            size: { width: 100, height: 30 },
            attrs: {
                path: { type: 'path', fill: T.signalBody, stroke: T.signalBody, strokeWidth: 0, pointerEvents: 'bounding-box' },
                label: { text: '', fill: T.labelDefault, fontSize: 14, fontWeight: 'bold' }
            },
            render: function (cell) { return renderArrow(cell, 'left'); },
            icon: function () {
                return `<svg viewBox="0 0 60 24"><polygon points="54,10 18,10 18,6 6,12 18,18 18,14 54,14" fill="${T.signalBody}"/></svg>`;
            }
        },
        /* ----- Signal stands (L-brackets connecting signal heads to track) ----- *
         *   examples.TopLine    — signal sits ABOVE track, stand drops DOWN
         *   examples.BottomLine — signal sits BELOW track, stand rises UP
         *   Both use position.x/y as the bounding-box origin and size.width/height
         *   as the L-bracket extents. Renderers are renderTopLine / renderBottomLine
         *   above.
         * ----------------------------------------------------------------------- */
        'examples.TopLine': {
            hidden: true, label: 'Signal Stand ↑', group: 'signal',
            size: { width: 37, height: 49 },
            attrs: {
                path: { type: 'path', fill: 'none', stroke: T.routeLine, strokeWidth: 4, pointerEvents: 'bounding-box' }
            },
            render: renderTopLine,
            icon: function () {
                return `<svg viewBox="0 0 32 32">` +
                    `<path d="M 6 28 L 6 8 Q 6 6 8 6 L 26 6" ` +
                    `stroke="${T.routeLine}" stroke-width="3.5" fill="none" ` +
                    `stroke-linecap="round" stroke-linejoin="round"/>` +
                    `</svg>`;
            }
        },
        'examples.BottomLine': {
            hidden: true, label: 'Signal Stand ↓', group: 'signal',
            size: { width: 37, height: 56 },
            attrs: {
                path: { type: 'path', fill: 'none', stroke: T.routeLine, strokeWidth: 4, pointerEvents: 'bounding-box' }
            },
            render: renderBottomLine,
            icon: function () {
                return `<svg viewBox="0 0 32 32">` +
                    `<path d="M 26 4 L 26 24 Q 26 26 24 26 L 6 26" ` +
                    `stroke="${T.routeLine}" stroke-width="3.5" fill="none" ` +
                    `stroke-linecap="round" stroke-linejoin="round"/>` +
                    `</svg>`;
            }
        }
    };

    function signalLampIcon(_colour, kind) {
        let svg = `<svg viewBox="0 0 60 32">` +
            `<rect x="20" y="2" width="20" height="28" rx="7" fill="#3a3a3a"/>` +
            `<rect x="21" y="3" width="18" height="26" rx="6" fill="#606060"/>` +
            `<circle cx="30" cy="16" r="9.5" fill="none" stroke="#2a2a2a" stroke-width="0.8"/>` +
            `<circle cx="30" cy="16" r="7" fill="#f4f4f4" stroke="#2a2a2a" stroke-width="1"/>` +
            `<circle cx="30" cy="16" r="5.8" fill="none" stroke="rgba(0,0,0,0.12)" stroke-width="0.8"/>`;
        if (kind === 'R') {
            svg += `<line x1="24" y1="15" x2="36" y2="15" stroke="#3a3a3a" stroke-width="1.2"/>` +
                `<line x1="24" y1="17" x2="36" y2="17" stroke="#3a3a3a" stroke-width="1.2"/>`;
        } else if (kind === 'G') {
            svg += `<line x1="30" y1="10" x2="30" y2="22" stroke="#3a3a3a" stroke-width="1.2"/>`;
        } else if (kind === 'Y') {
            svg += `<line x1="25" y1="11" x2="35" y2="21" stroke="#3a3a3a" stroke-width="1.2"/>`;
        } else if (kind === 'X') {
            svg += `<line x1="25" y1="12" x2="35" y2="22" stroke="#3a3a3a" stroke-width="1.2"/>` +
                `<line x1="25" y1="10" x2="35" y2="20" stroke="#3a3a3a" stroke-width="1.2"/>`;
        }
        return svg + `</svg>`;
    }

    /* ------------------------------------------------------------------------ *
     *  Toolbox groups
     * ------------------------------------------------------------------------ */
    const GROUPS = [
        { key: 'track', label: 'Track' },
        { key: 'point', label: 'Track & Point Machine' },
        { key: 'signal', label: 'Signal' },
        { key: 'shunt', label: 'Shunt / Axle / Gate' },
        { key: 'busbar', label: 'Bus Bar / Arrow' }
    ];

    /* ------------------------------------------------------------------------ *
     *  Public helpers
     * ------------------------------------------------------------------------ */
    function spec(type) { return ASSETS[type] || null; }

    function makeCell(type, x, y) {
        const s = ASSETS[type];
        if (!s) throw new Error('Unknown SIP asset type: ' + type);
        return {
            type: type,
            position: { x: x - s.size.width / 2, y: y - s.size.height / 2 },
            size: { width: s.size.width, height: s.size.height },
            angle: 0,
            id: uid(),
            z: 1,
            attrs: JSON.parse(JSON.stringify(s.attrs))
        };
    }

    function renderCell(cell) {
        const s = ASSETS[cell.type];
        let inner;
        if (!s) {
            const x = cell.position.x, y = cell.position.y;
            const w = (cell.size && cell.size.width) || 60;
            const h = (cell.size && cell.size.height) || 60;
            inner = `<g class="sip-asset sip-unknown" data-id="${cell.id}" data-type="${cell.type}">` +
                `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="rgba(255,46,46,0.2)" stroke="${T.lampRed}" stroke-dasharray="4,4"/>` +
                `<text x="${x + w / 2}" y="${y + h / 2}" text-anchor="middle" dominant-baseline="middle" fill="${T.lampRed}" font-family="${T.labelFont}" font-size="11">${escapeXml(cell.type)}</text>` +
                `</g>`;
        } else {
            inner = s.render(cell);
        }
        if (cell.angle && Math.abs(cell.angle) > 0.01) {
            const w = (cell.size && cell.size.width) || 60;
            const h = (cell.size && cell.size.height) || 60;
            const cx = (cell.position && cell.position.x || 0) + w / 2;
            const cy = (cell.position && cell.position.y || 0) + h / 2;
            return `<g transform="rotate(${cell.angle} ${cx} ${cy})">${inner}</g>`;
        }
        return inner;
    }

    function renderIcon(type) {
        const s = ASSETS[type];
        return s ? s.icon() : '';
    }

    function renderYard(opts) {
        opts = opts || {};
        const viewBox = opts.viewBox || '0 0 2000 740';
        const cells = opts.cells || [];
        const background = opts.background !== false;
        const className = opts.className || 'sip-yard';
        let bg = '';
        if (background) {
            bg = `<defs>` +
                `<linearGradient id="sipBg" x1="0" y1="0" x2="0" y2="1">` +
                `<stop offset="0%"   stop-color="#0c1530"/>` +
                `<stop offset="55%"  stop-color="#08101c"/>` +
                `<stop offset="100%" stop-color="#060a14"/>` +
                `</linearGradient>` +
                `</defs>` +
                `<rect width="100%" height="100%" fill="url(#sipBg)"/>`;
        }
        const body = cells.map(renderCell).join('\n');
        return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${viewBox}" class="${className}" preserveAspectRatio="xMidYMid meet">` +
            bg + body +
            `</svg>`;
    }

    /* ------------------------------------------------------------------------ *
     *  RAIL LAYER
     * ------------------------------------------------------------------------ */
    const TRACK_TYPES = { 'examples.Track': 1, 'examples.Track1': 1, 'examples.Track2': 1 };

    function renderRailLayer(cells) {
        if (!Array.isArray(cells) || cells.length === 0) return '';

        const Y_TOL = 40;
        const items = [];
        for (const c of cells) {
            if (!c || !TRACK_TYPES[c.type]) continue;
            const x = c.position.x;
            const y = c.position.y;
            const w = (c.size && c.size.width) || 60;
            const h = (c.size && c.size.height) || 60;
            const stroke = (c.attrs && c.attrs.path && c.attrs.path.stroke) || '#3c4260';
            items.push({
                cy: y + h / 2,
                xLeft: x,
                xRight: x + w,
                stroke: stroke,
                lit: isLit(stroke)
            });
        }
        if (!items.length) return '';

        items.sort(function (a, b) { return a.cy - b.cy || a.xLeft - b.xLeft; });
        const bands = [];
        let cur = null;
        for (const it of items) {
            if (!cur || (it.cy - cur.maxY) > Y_TOL) {
                cur = { items: [it], minY: it.cy, maxY: it.cy };
                bands.push(cur);
            } else {
                cur.items.push(it);
                cur.maxY = it.cy;
            }
        }

        // Publish band y-centres for renderStick() to find the nearest rail.
        _railContext.bands = bands.map(function (b) {
            const ys = b.items.map(function (i) { return i.cy; });
            return { cy: Math.round(ys[Math.floor(ys.length / 2)]) };
        });

        const patId = 'sipSleepers_' + Math.floor(Math.random() * 1e9).toString(36);
        const BED_H = 18;
        const SLEEP_W = 3;
        const SLEEP_STEP = 6;

        let svg = '<g class="sip-rail-layer" pointer-events="none">';
        svg += '<defs>' +
            '<pattern id="' + patId + '" x="0" y="0" width="' + SLEEP_STEP + '" height="' + BED_H + '" patternUnits="userSpaceOnUse">' +
            '<rect x="0" y="0" width="' + SLEEP_W + '" height="' + BED_H + '" fill="' + T.sleeper + '"/>' +
            '</pattern>' +
            '</defs>';

        for (const band of bands) {
            band.items.sort(function (a, b) { return a.xLeft - b.xLeft; });
            const ys = band.items.map(function (i) { return i.cy; });
            const cy = Math.round(ys[Math.floor(ys.length / 2)]);
            const minX = band.items[0].xLeft - 8;
            const maxX = band.items[band.items.length - 1].xRight + 8;
            const top = cy - BED_H / 2;

            svg += '<rect x="' + minX + '" y="' + top + '" width="' + (maxX - minX) + '" height="' + BED_H + '" ' +
                'fill="' + T.railBase + '"/>';
            svg += '<rect x="' + minX + '" y="' + top + '" width="' + (maxX - minX) + '" height="' + BED_H + '" ' +
                'fill="url(#' + patId + ')" opacity="0.55"/>';
            svg += '<line x1="' + minX + '" y1="' + top + '" x2="' + maxX + '" y2="' + top + '" ' +
                'stroke="' + T.railEdge + '" stroke-width="1.2"/>';
            svg += '<line x1="' + minX + '" y1="' + (top + BED_H) + '" x2="' + maxX + '" y2="' + (top + BED_H) + '" ' +
                'stroke="' + T.railEdge + '" stroke-width="1.2"/>';

            for (const it of band.items) {
                if (it.lit) {
                    svg += '<rect x="' + it.xLeft + '" y="' + (top - 3) + '" ' +
                        'width="' + (it.xRight - it.xLeft) + '" height="' + (BED_H + 6) + '" ' +
                        'fill="' + it.stroke + '" opacity="0.25" rx="2"/>';
                    svg += '<rect x="' + it.xLeft + '" y="' + top + '" ' +
                        'width="' + (it.xRight - it.xLeft) + '" height="' + BED_H + '" ' +
                        'fill="' + it.stroke + '" opacity="0.85"/>';
                    svg += '<rect x="' + it.xLeft + '" y="' + top + '" ' +
                        'width="' + (it.xRight - it.xLeft) + '" height="' + BED_H + '" ' +
                        'fill="url(#' + patId + ')" opacity="0.30"/>';
                }
            }
        }
        svg += '</g>';
        return svg;
    }

    /* ------------------------------------------------------------------------ *
     *  prepareRailContext — call BEFORE renderCell loops, so the signal/shunt
     *  L-sticks know where the rail bands are. The editor should invoke this
     *  once per render frame.
     * ------------------------------------------------------------------------ */
    function prepareRailContext(cells) {
        if (!Array.isArray(cells) || !cells.length) {
            _railContext.bands = [];
            return;
        }
        const Y_TOL = 40;
        const ys = [];
        for (const c of cells) {
            if (!c || !TRACK_TYPES[c.type]) continue;
            const cy = c.position.y + ((c.size && c.size.height) || 60) / 2;
            ys.push(cy);
        }
        if (!ys.length) { _railContext.bands = []; return; }
        ys.sort(function (a, b) { return a - b; });
        const bands = [];
        let cur = [ys[0]];
        for (let i = 1; i < ys.length; i++) {
            if (ys[i] - cur[cur.length - 1] > Y_TOL) {
                bands.push({ cy: Math.round(cur[Math.floor(cur.length / 2)]) });
                cur = [ys[i]];
            } else {
                cur.push(ys[i]);
            }
        }
        bands.push({ cy: Math.round(cur[Math.floor(cur.length / 2)]) });
        _railContext.bands = bands;
    }

    /* ------------------------------------------------------------------------ *
     *  STAND LAYER  —  auto-draws L-bracket stands for every signal group
     *  ------------------------------------------------------------------------
     *  Old-format data stores each signal as 2–3 separate aspect cells
     *  (examples.Signald90 = R, examples.Signal45 = Y, examples.Signal90 = G).
     *  This pre-pass:
     *    1. Clusters track cells into horizontal rail bands (same logic as
     *       renderRailLayer).
     *    2. Groups signal aspect cells by their label prefix (e.g. "S18 RG",
     *       "S18 HG", "S18 DG" → group "S18").
     *    3. Picks the rail band closest to each group's centroid.
     *    4. Emits one L-bracket SVG path linking the signal head to the rail.
     *
     *  No mutation of cells.  No new cells in the saved layout.  The stand is
     *  purely a render-time decoration so the same data renders consistently
     *  in the editor and the live telemetry view.
     *
     *  Toolbox-placed examples.TopLine / examples.BottomLine cells are still
     *  rendered separately (as ordinary cells) — they are how the user adds
     *  manual stands where the auto-layer hasn't.
     * ------------------------------------------------------------------------ */
    const LAMP_TYPES_FOR_STAND = {
        'examples.Signald90': 1,
        'examples.Signal45': 1,
        'examples.Signal90': 1,
        'examples.Signald45': 1
    };

    function renderStandLayer(cells) {
        if (!Array.isArray(cells) || cells.length === 0) return '';

        const TRACK_TYPES_LOCAL = { 'examples.Track': 1, 'examples.Track1': 1, 'examples.Track2': 1 };
        const Y_TOL = 40;

        /* ---- 1. Rail bands from track Y centres -------------------------- */
        const ys = [];
        for (const c of cells) {
            if (!c || !TRACK_TYPES_LOCAL[c.type]) continue;
            const h = (c.size && +c.size.height) || 0;
            const y = (c.position && +c.position.y) || 0;
            ys.push(y + h / 2);
        }
        if (!ys.length) return '';
        ys.sort((a, b) => a - b);

        const bands = [];
        let cur = { values: [ys[0]], max: ys[0] };
        for (let i = 1; i < ys.length; i++) {
            if (ys[i] - cur.max <= Y_TOL) { cur.values.push(ys[i]); cur.max = ys[i]; }
            else { bands.push(cur); cur = { values: [ys[i]], max: ys[i] }; }
        }
        bands.push(cur);
        for (const b of bands) {
            let s = 0; for (const v of b.values) s += v;
            b.mean = Math.round(s / b.values.length);
        }
        function snapBand(y) {
            let best = bands[0], bd = Math.abs(y - bands[0].mean);
            for (const b of bands) {
                const d = Math.abs(y - b.mean);
                if (d < bd) { bd = d; best = b; }
            }
            return best.mean;
        }

        /* ---- 2. Group signal aspect cells by label prefix --------------- */
        const groups = {};
        for (const c of cells) {
            if (!c || !LAMP_TYPES_FOR_STAND[c.type]) continue;
            const lbl = c.attrs && c.attrs.label && c.attrs.label.text ? String(c.attrs.label.text) : '';
            const prefix = lbl ? lbl.split(/\s+/)[0] : '';
            if (!prefix) continue;
            const w = (c.size && +c.size.width) || 60;
            const h = (c.size && +c.size.height) || 60;
            const cx = ((c.position && +c.position.x) || 0) + w / 2;
            const cy = ((c.position && +c.position.y) || 0) + h / 2;
            const g = groups[prefix] || (groups[prefix] = { xs: [], ys: [], minX: Infinity, maxX: -Infinity });
            g.xs.push(cx); g.ys.push(cy);
            if (cx < g.minX) g.minX = cx;
            if (cx > g.maxX) g.maxX = cx;
        }

        /* ---- 3. Emit one L-bracket per group ---------------------------- */
        let svg = '<g class="sip-stand-layer" style="pointer-events:none">';
        for (const prefix in groups) {
            const g = groups[prefix];
            let sx = 0, sy = 0;
            for (const x of g.xs) sx += x;
            for (const y of g.ys) sy += y;
            const gx = sx / g.xs.length;
            const gy = sy / g.ys.length;
            const railY = snapBand(gy);
            const delta = railY - gy;          // +ve = signal above rail
            if (Math.abs(delta) < 8) continue;  // signal already on rail — no stand needed

            /* Choose the L-bracket geometry. Stand starts at one extreme x of
               the signal group (outermost aspect) and bends toward the rail. */
            let cornerX, armStartX, armY, dropEndY;
            if (delta > 0) {
                /* Signal above rail → arm runs RIGHT off the rightmost aspect,
                   then drops DOWN to the rail. */
                armStartX = g.maxX + 18;        // step out past the signal head
                cornerX = armStartX + 16;     // short horizontal arm
                armY = gy + 4;
                dropEndY = railY - 4;
            } else {
                /* Signal below rail → arm runs LEFT off the leftmost aspect,
                   then rises UP to the rail. */
                armStartX = g.minX - 18;
                cornerX = armStartX - 16;
                armY = gy - 4;
                dropEndY = railY + 4;
            }
            const r = 4;
            const armSign = (cornerX > armStartX) ? 1 : -1;
            const dropSign = (dropEndY > armY) ? 1 : -1;
            const cornerIn = cornerX - armSign * r;
            const cornerOut = armY + dropSign * r;

            const d = 'M ' + armStartX + ' ' + armY + ' ' +
                'L ' + cornerIn + ' ' + armY + ' ' +
                'Q ' + cornerX + ' ' + armY + ' ' +
                cornerX + ' ' + cornerOut + ' ' +
                'L ' + cornerX + ' ' + dropEndY;

            svg += '<path d="' + d + '" stroke="' + T.routeLine +
                '" stroke-width="4" fill="none" stroke-linecap="round" ' +
                'stroke-linejoin="round" data-stand-for="' + prefix + '"/>';
        }
        svg += '</g>';
        return svg;
    }

    /* ------------------------------------------------------------------------ *
     *  BREAKER LAYER  —  auto-draws insulated rail joints at every rail end
     *  ------------------------------------------------------------------------
     *  Mirrors renderRailLayer's band-clustering, then emits one yellow
     *  vertical bar at the leftmost xLeft and one at the rightmost xRight
     *  of each band — i.e. the physical tips of the rail.
     *
     *  Manually-placed examples.TrackBreaker cells are detected first and
     *  any auto-breaker within NEAR_PX of one is suppressed so the user's
     *  placement always wins.
     *
     *  Like the stand/rail layers, this is purely a render-time decoration
     *  — nothing is written to the saved layout.
     * ------------------------------------------------------------------------ */
    function renderBreakerLayer(cells) {
        if (!Array.isArray(cells) || cells.length === 0) return '';

        const TRACK_TYPES_LOCAL = { 'examples.Track': 1, 'examples.Track1': 1, 'examples.Track2': 1 };
        const Y_TOL = 40;
        const NEAR_PX = 18;

        /* 1. Collect manual breakers so we don't duplicate them. */
        const manualBreakers = [];
        for (const c of cells) {
            if (!c || c.type !== 'examples.TrackBreaker') continue;
            const w = (c.size && +c.size.width) || 12;
            const h = (c.size && +c.size.height) || 26;
            manualBreakers.push({
                cx: (c.position && +c.position.x || 0) + w / 2,
                cy: (c.position && +c.position.y || 0) + h / 2
            });
        }
        function manualNear(x, y) {
            for (const m of manualBreakers) {
                if (Math.abs(m.cx - x) < NEAR_PX && Math.abs(m.cy - y) < NEAR_PX) return true;
            }
            return false;
        }

        /* 2. Cluster track cells into rail bands (same as renderRailLayer). */
        const items = [];
        for (const c of cells) {
            if (!c || !TRACK_TYPES_LOCAL[c.type]) continue;
            const x = (c.position && +c.position.x) || 0;
            const y = (c.position && +c.position.y) || 0;
            const w = (c.size && +c.size.width) || 60;
            const h = (c.size && +c.size.height) || 60;
            items.push({ cy: y + h / 2, xLeft: x, xRight: x + w });
        }
        if (!items.length) return '';

        items.sort(function (a, b) { return a.cy - b.cy || a.xLeft - b.xLeft; });
        const bands = [];
        let cur = null;
        for (const it of items) {
            if (!cur || (it.cy - cur.maxY) > Y_TOL) {
                cur = { items: [it], maxY: it.cy };
                bands.push(cur);
            } else {
                cur.items.push(it);
                cur.maxY = it.cy;
            }
        }

        /* 3. Emit a breaker at each rail tip, matching the +/-8 padding that
              renderRailLayer uses so the bar sits at the visible rail edge. */
        const barW = 3;
        const barH = 26;
        let svg = '<g class="sip-breaker-layer" pointer-events="none">';
        for (const band of bands) {
            band.items.sort(function (a, b) { return a.xLeft - b.xLeft; });
            const ys = band.items.map(function (i) { return i.cy; });
            const cy = Math.round(ys[Math.floor(ys.length / 2)]);
            const minX = band.items[0].xLeft - 8;
            const maxX = band.items[band.items.length - 1].xRight + 8;

            const ends = [
                { x: minX, y: cy },
                { x: maxX, y: cy }
            ];
            for (const e of ends) {
                if (manualNear(e.x, e.y)) continue;
                svg += '<rect x="' + (e.x - barW / 2 - 1) + '" y="' + (e.y - barH / 2 - 1) + '" ' +
                    'width="' + (barW + 2) + '" height="' + (barH + 2) + '" fill="#0a0f1e"/>';
                svg += '<rect x="' + (e.x - barW / 2) + '" y="' + (e.y - barH / 2) + '" ' +
                    'width="' + barW + '" height="' + barH + '" fill="#FFD400"/>';
            }
        }
        svg += '</g>';
        return svg;
    }

    /* ------------------------------------------------------------------------ *
     *  Export
     * ------------------------------------------------------------------------ */
    const SIP = {
        GROUPS, PALETTE: Object.keys(ASSETS), ASSETS,
        spec, makeCell, renderCell, renderIcon, renderYard,
        renderRailLayer, prepareRailContext, renderStandLayer, renderBreakerLayer,
        _uid: uid, _theme: T
    };

    if (typeof module !== 'undefined' && module.exports) module.exports = { SIP };
    if (typeof window !== 'undefined') window.SIP = SIP;

})();
